package com.eample2.hi_messenger.LoginSignup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.eample2.hi_messenger.MainActivity;
import com.eample2.hi_messenger.R;
import com.firebase.ui.auth.data.model.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessaging;

public class LoginActivity extends AppCompatActivity {
    TextView needanewAccount , forgotpassword;
    Button phonenologIn , Login;
    EditText email,password;
    DatabaseReference UserRef;
    FirebaseAuth auth;
    ProgressDialog progressDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Initialize();
        progressDialog = new ProgressDialog(this);
        UserRef= FirebaseDatabase.getInstance().getReference().child("Users");
        needanewAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SendusertoregActivity();
            }
        });
        phonenologIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SendusertophoneActivity();
            }
        });
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AllowUserLogin();
            }
        });
        forgotpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendLinktomail();
                
            }
        });
        
    }

    private void sendLinktomail() {
        if (email.getText().toString().matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$") && email.getText().toString().length()>8){
            AlertDialog.Builder passwordreset  = new AlertDialog.Builder(this);
            passwordreset.setTitle("Reset Password ? ");
            passwordreset.setMessage("Press Yes to receive the Link ");
            passwordreset.setPositiveButton("YES" , (dialogInterface, i) ->
                    {
                        String resetEmail = email.getText().toString();
                        auth.sendPasswordResetEmail(resetEmail).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                Toast.makeText(getApplicationContext(), "Reset email link has been sent to your id", Toast.LENGTH_SHORT).show();

                            }
                        });
                    });
                passwordreset.setNegativeButton("NO" , (dialogInterface, i) -> {});
                passwordreset.create().show();
        }
        else {
            email.setError("Please enter a valid email");
        }

    }

    private void AllowUserLogin() {
        String userEmail = email.getText().toString();
        String userPassword = password.getText().toString();
        if (TextUtils.isEmpty(userEmail)){
            email.setError("Please Enter Email id");
        }
        if (TextUtils.isEmpty(userPassword)){
            password.setError("Please Enter Password");
        }
        if (TextUtils.isEmpty(userEmail) && TextUtils.isEmpty(userPassword)){
            email.setError("Please Enter Email");
            password.setError("Please Enter Password");
        }
        if (!TextUtils.isEmpty(userEmail) && !TextUtils.isEmpty(userPassword)) {
            progressDialog.setTitle("Signing In");
            progressDialog.setMessage("Please wait ! while we log in to your Account");
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();
            auth.signInWithEmailAndPassword(userEmail , userPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful())
                    {
                        final String[] deviceToken = new String[1];
                        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(new OnCompleteListener<String>() {
                            @Override
                            public void onComplete(@NonNull Task<String> task) {
                                deviceToken[0] =task.getResult();

                            }
                        });
                        String currentUserId = auth.getCurrentUser().getUid();
                        UserRef.child(currentUserId).child("device_Token").setValue(deviceToken[0]).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                SendUserToMainActivity();
                                Toast.makeText(getApplicationContext(), "LoggedIn Successfully", Toast.LENGTH_SHORT).show();
                            }
                        });


                    }
                    else {
                        String message = task.getException().getLocalizedMessage();
                        Toast.makeText(getApplicationContext(), "Error " + message, Toast.LENGTH_SHORT).show();
                    }
                    progressDialog.cancel();
                    progressDialog.dismiss();

                }
            });
        }

    }

    private void SendusertoregActivity() {
        Intent intent = new Intent(LoginActivity.this , RegisterActivity.class);
            startActivity(intent);
    }

    private void SendusertophoneActivity() {
        Intent intent = new Intent(LoginActivity.this , PhnoLoginActivity.class);
        startActivity(intent);
    }

    private void SendUserToMainActivity() {
        Intent intent = new Intent(LoginActivity.this , MainActivity.class);
        intent.addFlags(intent.FLAG_ACTIVITY_NEW_TASK | intent.FLAG_ACTIVITY_CLEAR_TASK);

        startActivity(intent);
        finish();
    }


    private void Initialize() {
        needanewAccount =findViewById(R.id.needanewaccount);
        email = findViewById(R.id.login_email);
        password =findViewById(R.id.login_password);
        Login = findViewById(R.id.login_btn);
        forgotpassword = findViewById(R.id.forgot_password);
        phonenologIn=findViewById(R.id.phone_number_login);
        auth = FirebaseAuth.getInstance();


    }
}