package com.eample2.hi_messenger;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.eample2.hi_messenger.LoginSignup.LoginActivity;
import com.eample2.hi_messenger.LoginSignup.RegisterActivity;
import com.eample2.hi_messenger.helper.TabAccessorAdapter;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.tabs.TabLayout;
import com.google.common.base.Verify;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    Toolbar toolbar;
     ViewPager mainviewPager;
     TabLayout tabLayout;
     TabAccessorAdapter tabAccessorAdapter;
     FirebaseAuth auth;
     ProgressDialog progressDialog;
     DatabaseReference RootRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        auth= FirebaseAuth.getInstance();
        RootRef= FirebaseDatabase.getInstance().getReference();
        toolbar =findViewById(R.id.main_activity_toolbar);
        mainviewPager =findViewById(R.id.main_tab_viewPager);
        tabLayout=findViewById(R.id.main_tabs);
        tabAccessorAdapter=new TabAccessorAdapter(getSupportFragmentManager());
        mainviewPager.setAdapter(tabAccessorAdapter);
        setSupportActionBar(toolbar);
        tabLayout.setupWithViewPager(mainviewPager);
        getSupportActionBar().setTitle("hi-Messenger");



    }

    @Override
    protected void onStart() {

        super.onStart();
        FirebaseUser currentUser=auth.getCurrentUser();
        if (currentUser==null){
            auth.signOut();
            SendUserToLoginActivity();

        }
        else {
            progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Loading Chats");
            progressDialog.setMessage("Please wait ! while we Load your Chats");
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();
            updateuserstatusStart("online");
            VerifyExistenceofuser();
        }
    }

    @Override
    protected void onPause() {

        super.onPause();
        FirebaseUser currentUser=auth.getCurrentUser();
        if (currentUser!=null){
            updateuserstatus("offline");

        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        FirebaseUser currentUser=auth.getCurrentUser();
        if (currentUser!=null){
            updateuserstatus("online");

        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_DEFAULT);
        main.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(main);
        FirebaseUser currentUser=auth.getCurrentUser();
        if (currentUser!=null){
            updateuserstatus("offline");

        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();        FirebaseUser currentUser=auth.getCurrentUser();
        if (currentUser!=null){
            updateuserstatus("offline");

        }
    }

    private void updateuserstatus(String status) {
        String currentUserId = auth.getCurrentUser().getUid();
        String currentTime , currentDate;
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd,yyy");
        currentDate=dateFormat.format(calendar.getTime());
        SimpleDateFormat timeformat= new SimpleDateFormat("hh:mm a");
        currentTime=timeformat.format(calendar.getTime());
        HashMap<String , Object> userStateMap = new HashMap<>();
        userStateMap.put("time",  currentTime);
        userStateMap.put("date", currentDate);
        userStateMap.put("state", status  );
        RootRef.child("Users").child(currentUserId).child("userState").updateChildren(userStateMap);


    }
    private void updateuserstatusStart(String status) {
        String currentUserId = auth.getCurrentUser().getUid();
        String currentTime , currentDate;
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd,yyy");
        currentDate=dateFormat.format(calendar.getTime());
        SimpleDateFormat timeformat= new SimpleDateFormat("hh:mm a");
        currentTime=timeformat.format(calendar.getTime());
        HashMap<String , Object> userStateMap = new HashMap<>();
        userStateMap.put("time",  currentTime);
        userStateMap.put("date", currentDate);
        userStateMap.put("state", status  );
        RootRef.child("Users").child(currentUserId).child("userState").updateChildren(userStateMap).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                progressDialog.cancel();
            }
        });


    }

    private void VerifyExistenceofuser() {
            String currentUserId = auth.getCurrentUser().getUid();
            RootRef.child("Users").child(currentUserId).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if ((snapshot.child("name")).exists())
                    {

                    }
                    else {
                        SendUserToSettingsActivity();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
    }


    private void SendUserToLoginActivity() {
        Intent intent = new Intent(MainActivity.this , LoginActivity.class);
        startActivity(intent);
    }
    private void SendUserToSettingsActivity() {
        Intent intent = new Intent(MainActivity.this , SettingsActivity.class);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.option_menu , menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);
        if (item.getItemId()==R.id.Logout){
            FirebaseUser currentUser=auth.getCurrentUser();
            if (currentUser!=null){
                updateuserstatus("offline");

            }
            auth.signOut();
            SendUserToLoginActivity();
        }
        if (item.getItemId()==R.id.main_settings){
            SendUserToSettingsActivity();
        }
        return true;
    }
}