package com.eample2.hi_messenger.helper;

public class MessageAdapter {
}
