package com.eample2.hi_messenger;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.eample2.hi_messenger.helper.Contacts;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import de.hdodenhof.circleimageview.CircleImageView;

public class FindFreinds extends AppCompatActivity {
    RecyclerView findFreindList;
    Toolbar toolbar;
    DatabaseReference UserRef;
    private StorageReference StorageReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_freinds);
        findFreindList = findViewById(R.id.findff_recyclerview);
            toolbar = findViewById(R.id.find_friends_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Find Friends");
        UserRef= FirebaseDatabase.getInstance().getReference().child("Users");

        findFreindList.setLayoutManager(new LinearLayoutManager(this));

    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseRecyclerOptions<Contacts> options = new FirebaseRecyclerOptions.Builder<Contacts>().setQuery(UserRef , Contacts.class).build();
        FirebaseRecyclerAdapter<Contacts , FindFreindsViewHolder> adapter = new FirebaseRecyclerAdapter<Contacts, FindFreindsViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull FindFreindsViewHolder holder, @SuppressLint("RecyclerView") int position, @NonNull Contacts model) {
                holder.userName.setText(model.getName());
                holder.userStatus.setText(model.getStatus());
                if (model.getImage()!=null)
                {
                    GetImage(model.getImage() , holder.profileImage);
                }
                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                    String user = getRef(position).getKey();
                    Intent profileIntent = new Intent(FindFreinds.this , ProfileActivity.class);
                    profileIntent.putExtra("visited_uid" , user);
                    startActivity(profileIntent);
                    }
                });

            }

            @NonNull
            @Override
            public FindFreindsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.user_display_layout , parent , false);
                FindFreindsViewHolder viewHolder = new FindFreindsViewHolder(view);
                return viewHolder;
            }
        };

        findFreindList.setAdapter(adapter);
        adapter.startListening();


    }
    public static class FindFreindsViewHolder extends RecyclerView.ViewHolder
    {
        TextView userName , userStatus;
        CircleImageView profileImage;


        public FindFreindsViewHolder(@NonNull View itemView) {
            super(itemView);
            userName = itemView.findViewById(R.id.user_profile_name);
            userStatus = itemView.findViewById(R.id.user_profile_status);
            profileImage = itemView.findViewById(R.id.users_profile_image);
            userStatus.setVisibility(View.VISIBLE);
        }
    }

    private void GetImage(String CurrentUser , CircleImageView imageView) {
        StorageReference = FirebaseStorage.getInstance().getReference().child("Profile Images/" + CurrentUser + ".jpg");
        StorageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Glide.with(getApplicationContext()).load(uri).into(imageView);

            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(FindFreinds.this , MainActivity.class);
        startActivity(intent);
    }
}