package com.eample2.hi_messenger.LoginSignup;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.eample2.hi_messenger.MainActivity;
import com.eample2.hi_messenger.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessaging;

public class RegisterActivity extends AppCompatActivity {
    EditText regEmail,regPassword;
    TextView alreadyHaveanAccount;
    Button createanewAccount;
    FirebaseAuth auth;
    ProgressDialog progressDialog;
    DatabaseReference RootRef;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Initialize();
        auth=FirebaseAuth.getInstance();
        RootRef= FirebaseDatabase.getInstance().getReference();
        alreadyHaveanAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SendUserToLoginActivity();
            }
        });
        createanewAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createnewAccount();
            }
        });

    }
    private void createnewAccount(){
        String userEmail = regEmail.getText().toString();
        String userPassword = regPassword.getText().toString();
        if (TextUtils.isEmpty(userEmail)){
            regEmail.setError("Please Enter Email id");
        }
        if (TextUtils.isEmpty(userPassword)){
            regPassword.setError("Please Enter Password");
        }
        if (TextUtils.isEmpty(userEmail) && TextUtils.isEmpty(userPassword)){
            regEmail.setError("Please Enter Email");
            regPassword.setError("Please Enter Password");
        }
        if (!TextUtils.isEmpty(userEmail) && !TextUtils.isEmpty(userPassword)){
            progressDialog.setTitle("Create New Account");
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.setMessage("please wait while we create your account");
            progressDialog.show();
            auth.createUserWithEmailAndPassword(userEmail,userPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
               if (task.isSuccessful())
               {
                   final String[] deviceToken = new String[1];
                   FirebaseMessaging.getInstance().getToken().addOnCompleteListener(new OnCompleteListener<String>() {
                       @Override
                       public void onComplete(@NonNull Task<String> task) {
                                deviceToken[0] =task.getResult();

                       }
                   });
                   String currentUserId = auth.getCurrentUser().getUid();
                   RootRef.child("Users").child(currentUserId).setValue("");
                   RootRef.child("Users").child(currentUserId).child("device_Token").setValue(deviceToken[0]);
                   SendUserToMainActivity();
                   Toast.makeText(getApplicationContext(), "Account Created Successfully", Toast.LENGTH_SHORT).show();
               }
               else {
                   Toast.makeText(getApplicationContext(), "Error Occurred while creating Account", Toast.LENGTH_SHORT).show();
               }
               progressDialog.cancel();
               progressDialog.dismiss();
                }
            });
        }


    }

    private void SendUserToLoginActivity() {
        Intent intent = new Intent(RegisterActivity.this , LoginActivity.class);
        startActivity(intent);
    }
    private void SendUserToMainActivity() {
        Intent intent = new Intent(RegisterActivity.this , MainActivity.class);
        intent.addFlags(intent.FLAG_ACTIVITY_NEW_TASK | intent.FLAG_ACTIVITY_CLEAR_TASK);

        startActivity(intent);
        finish();
    }

    private void Initialize() {
        regEmail=findViewById(R.id.signip_email);
        regPassword=findViewById(R.id.signup_password);
        alreadyHaveanAccount=findViewById(R.id.already_have_acc);
        createanewAccount=findViewById(R.id.signup_btn);
        progressDialog = new ProgressDialog(this);


    }
}