package com.eample2.hi_messenger;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileActivity extends AppCompatActivity {
    String receiveUserId , senderUserId , Current_state;
     CircleImageView userProfImage;
     TextView userProfileName , userProfileStatus;
     Button DeclineReq , SendMsgReq;
     FirebaseAuth auth;
     String image;
     DatabaseReference RootRef , ChatReqRef , ContactRef , NotificationRef;
     StorageReference userProfileImageRef;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        receiveUserId = getIntent().getExtras().getString("visited_uid");
        Initailize();
        Retrivedata();

    }

    private void Retrivedata()  {

        RootRef.child("Users").child(receiveUserId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    if (snapshot.hasChild("name") && snapshot.hasChild("status") && !snapshot.hasChild("image"))
                    {

                        String uname = snapshot.child("name").getValue().toString();
                        String ustatus = snapshot.child("status").getValue().toString();
                        userProfileName.setText(uname);
                        userProfileStatus.setText(ustatus);


                    }
                    else if (snapshot.hasChild("name") && snapshot.hasChild("status") && snapshot.hasChild("image"))
                    {

                        image=snapshot.child("image").getValue().toString();
                        String uname = snapshot.child("name").getValue().toString();
                        String ustatus = snapshot.child("status").getValue().toString();
                        GetImage(receiveUserId , userProfImage);
                        userProfileName.setText(uname);
                        userProfileStatus.setText(ustatus);


                    }
                    else {

                        Toast.makeText(getApplicationContext(), "Please Update Your Profile", Toast.LENGTH_SHORT).show();
                    }
                    ManageChatRequest();
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    private void ManageChatRequest() {
        ChatReqRef.child(senderUserId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                if (snapshot.hasChild(receiveUserId)) {
                    String request_type = snapshot.child(receiveUserId).child("request_type").getValue().toString();
                    if (request_type.equals("sent")) {
                        Current_state = "request_sent";
                        SendMsgReq.setText("Cancel Chat Request");
                    } else if (request_type.equals("received")) {
                        Current_state = "request_received";
                        SendMsgReq.setText("Accept Chat Request");
                        DeclineReq.setVisibility(View.VISIBLE);
                        DeclineReq.setEnabled(true);
                        DeclineReq.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                CancelRequestSent();
                            }
                        });
                    }
                }
                else {
                    ContactRef.child(senderUserId).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.hasChild(receiveUserId)) {
                                Current_state = "friends";
                                SendMsgReq.setText("Remove This Contact");
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }

        });
        if (!senderUserId.equals(receiveUserId))
        {
            SendMsgReq.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SendMsgReq.setEnabled(true);
                    if (Current_state.equals("new"))
                    {
                        SendChatRequest();
                    }
                    if (Current_state.equals("request_sent"))
                    {
                        CancelRequestSent();
                    }
                    if (Current_state.equals("request_received"))
                    {
                        AcceptChatRequest();
                    }
                    if (Current_state.equals("friends"))
                    {
                        RemoveSpecificContact();
                    }
                }
            });
        }
        else {
            SendMsgReq.setVisibility(View.INVISIBLE);

        }


    }

    private void RemoveSpecificContact() {
        ContactRef.child(senderUserId).child(receiveUserId).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
           if (task.isSuccessful())
           {
               SendMsgReq.setEnabled(true);
               Current_state = "new";
               SendMsgReq.setText("Send Message");
               DeclineReq.setVisibility(View.INVISIBLE);
               DeclineReq.setEnabled(false);

           }
            }
        });
    }

    private void AcceptChatRequest() {
        ContactRef.child(senderUserId).child(receiveUserId).child("Contacts").setValue("Saved").addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
           if (task.isSuccessful())
           {
               ContactRef.child(receiveUserId).child(senderUserId).child("Contacts").setValue("Saved").addOnCompleteListener(new OnCompleteListener<Void>() {
                   @Override
                   public void onComplete(@NonNull Task<Void> task) {
                       if (task.isSuccessful()){
                       ChatReqRef.child(senderUserId).child(receiveUserId).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                           @Override
                           public void onComplete(@NonNull Task<Void> task) {
                               if (task.isSuccessful()){
                               ChatReqRef.child(receiveUserId).child(senderUserId).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                   @Override
                                   public void onComplete(@NonNull Task<Void> task) {
                                       if (task.isSuccessful()){
                                       SendMsgReq.setEnabled(true);
                                       Current_state = "friends";
                                       SendMsgReq.setText("Remove This Contact");
                                       DeclineReq.setVisibility(View.INVISIBLE);
                                       DeclineReq.setEnabled(false);


                                   }}
                               });

                           }}
                       });

                   }}
               });

           }
            }
        });
    }

    private void SendChatRequest() {
        ChatReqRef.child(senderUserId).child(receiveUserId).child("request_type").setValue("sent").addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {

                ChatReqRef.child(receiveUserId).child(senderUserId).child("request_type").setValue("received").addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {


                                if (task.isSuccessful())
                                {
                                    SendMsgReq.setEnabled(true);
                                    Current_state="request_sent";
                                    SendMsgReq.setText("Cancel Chat Request");
                                }




                    }
                });

            }
        });
    }

    private void CancelRequestSent() {

        ChatReqRef.child(senderUserId).child(receiveUserId).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {


                    ChatReqRef.child(receiveUserId).child(senderUserId).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful())
                            {

                            SendMsgReq.setEnabled(true);
                            Current_state = "new";
                            SendMsgReq.setText("Send Message");
                            DeclineReq.setVisibility(View.INVISIBLE);
                            DeclineReq.setEnabled(false);


                        }}
                    });
                }
            }
        });


    }

    private void Initailize() {
        auth = FirebaseAuth.getInstance();
        senderUserId = auth.getCurrentUser().getUid();
        RootRef= FirebaseDatabase.getInstance().getReference();
        userProfileImageRef = FirebaseStorage.getInstance().getReference().child("Profile Images");
        ChatReqRef= FirebaseDatabase.getInstance().getReference().child("Chat Request");
        ContactRef= FirebaseDatabase.getInstance().getReference().child("Contacts");
        NotificationRef= FirebaseDatabase.getInstance().getReference().child("Notifications");
        userProfileName = findViewById(R.id.user_name_profileActivity);
        userProfileStatus = findViewById(R.id.user_status_profileActivity);
        SendMsgReq = findViewById(R.id.send_Message);
        DeclineReq = findViewById(R.id.Can_req_btn);
        userProfImage = findViewById(R.id.profile_image);
        Current_state = "new";


    }
    private void GetImage(String CurrentUser , CircleImageView imageView) {
        StorageReference storageReference= FirebaseStorage.getInstance().getReference().child("Profile Images/" + CurrentUser + ".jpg");
        storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Glide.with(getApplicationContext()).load(uri).into(imageView);

            }
        });
    }
}