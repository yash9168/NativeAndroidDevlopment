package com.example.android.ola_clone;

public class PayPalConfig {
    public static final String PAYPAL_CLIENT_ID = "Achpkm2KZyQhd44TxHtW1ZaWeD_8y2eTjz_ABLbAopF4UScWy3Z0oLDbrJOo3HC4CuwklFa4nOQRN6OY";
}
