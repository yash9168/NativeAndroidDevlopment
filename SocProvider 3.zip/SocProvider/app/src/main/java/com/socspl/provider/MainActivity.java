package com.socspl.provider;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.socspl.provider.activity.LoginActivity;
import com.socspl.provider.activity.MainScreen;
import com.socspl.provider.model.User;
import com.socspl.provider.util.SessionManager;

public class MainActivity extends AppCompatActivity {

    SessionManager sessionManager;
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sessionManager = new SessionManager(MainActivity.this);
        Thread timer = new Thread() {
            public void run() {
                try {
                    sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    if (!sessionManager.getUserStatus().equals("0")) {
                        startActivity(new Intent(getApplicationContext(), MainScreen.class));
                    } else {
                        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                    }
                    finishAffinity();

                }
            }
        };
        timer.start();
    }
}