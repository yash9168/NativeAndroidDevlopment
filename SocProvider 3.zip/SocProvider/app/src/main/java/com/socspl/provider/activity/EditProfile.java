package com.socspl.provider.activity;

import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.swiperefreshlayout.widget.CircularProgressDrawable;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.canhub.cropper.CropImage;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;
import com.socspl.provider.R;
import com.socspl.provider.databinding.ActivityEditProfileBinding;
import com.socspl.provider.util.CustPrograssbar;
import com.socspl.provider.util.MySingleton;
import com.socspl.provider.util.SessionManager;
import com.socspl.provider.util.ToastMessage;
import com.squareup.picasso.Picasso;

import net.gotev.uploadservice.MultipartUploadRequest;
import net.gotev.uploadservice.ServerResponse;
import net.gotev.uploadservice.UploadInfo;
import net.gotev.uploadservice.UploadStatusDelegate;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import static android.content.ContentValues.TAG;

public class EditProfile extends AppCompatActivity {

    ActivityEditProfileBinding binding;
    CustPrograssbar custPrograssbar;
    private Uri uriPath;
    SessionManager manager;
    String filePath;
    private static int AUTOCOMPLETE_REQUEST_CODE = 1;
    LatLng latLng;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_edit_profile);
        binding.topAppBar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        Places.initialize(getApplicationContext(), getString(R.string.MapKey));

        // Create a new PlacesClient instance
        PlacesClient placesClient = Places.createClient(this);
        manager = new SessionManager(EditProfile.this);
        custPrograssbar = new CustPrograssbar();
        getProfile();
        getLocation();

        binding.imageViewEditPro.setOnClickListener(v -> {
            CropImage.activity()
                    .start( this);
        });

        binding.buttonEditProfile.setOnClickListener(v -> {
            if (!TextUtils.isEmpty(filePath))
            updateProfile();
            else
                updateNewProfile();

        });

        binding.address.setOnClickListener(v -> {
            List<Place.Field> fields = Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG);

            // Start the autocomplete intent.
            Intent intent = new Autocomplete.IntentBuilder(AutocompleteActivityMode.FULLSCREEN, fields)
                    .build(getApplicationContext());
            startActivityForResult(intent, AUTOCOMPLETE_REQUEST_CODE);
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
                CropImage.ActivityResult result = CropImage.getActivityResult(data);
                if (resultCode == RESULT_OK) {
                    uriPath = result.getUriContent();
                    String s = "" + result.getUriContent();
                    CircularProgressDrawable circularProgressDrawable = new CircularProgressDrawable(getApplicationContext());
                    circularProgressDrawable.setStrokeWidth(5f);
                    circularProgressDrawable.setCenterRadius(30f);
                    circularProgressDrawable.start();
                    String path_data = result.getUriFilePath(this, true);
                    Picasso.with(EditProfile.this).load(uriPath).placeholder(circularProgressDrawable).into(binding.imageViewUserEditPro);
                    filePath = result.getUriFilePath(EditProfile.this, true);
                } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                    Exception error = result.getError();
                }
            } else if (requestCode == AUTOCOMPLETE_REQUEST_CODE) {
                if (resultCode == RESULT_OK) {
                    Place place = Autocomplete.getPlaceFromIntent(data);
                    latLng = place.getLatLng();
                    Geocoder geocoder = new Geocoder(this, Locale.getDefault());
                    List<Address> addresses = null;
                    try {
                        addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    String cityName = addresses.get(0).getLocality();

                    if (locationList != null && locationList.size() > 0) {
                        if (locationList.contains(cityName)) {
                            binding.address.setText(place.getName());
                        } else
                            SessionManager.showToast(EditProfile.this, getString(R.string.service_not_available));
                    }
                } else if (resultCode == AutocompleteActivity.RESULT_ERROR) {
                    // TODO: Handle the error.
                    Status status = Autocomplete.getStatusFromIntent(data);
                    Log.i(TAG, status.getStatusMessage());
                } else if (resultCode == RESULT_CANCELED) {
                    // The user canceled the operation.
                }
            }
        }
    }
    private ArrayList<String> locationList ;
    String provider_city_id;

    private  void getLocation(){
        JsonArrayRequest request = new JsonArrayRequest(SessionManager.CITY, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                locationList = new ArrayList<>();
                for (int i = 0; i <response.length() ; i++) {
                    try {
                        JSONObject object = response.getJSONObject(i);
                        String city_name =  object.getString("city_name");
                        locationList.add(city_name);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        request.setRetryPolicy(new DefaultRetryPolicy(20000, 1, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        MySingleton.getInstance(EditProfile.this).addToRequestQueue(request);
    }
    private String containsCity(JSONArray jsonArray, String city) throws JSONException {
        if (jsonArray.length() > 0) {
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                if (jsonObject.optString("city_name").equalsIgnoreCase(city)) {
                    return jsonObject.optString("id");
                }
            }

        }
        return "";
    }

    private void getProfile() {
        custPrograssbar.prograssCreate(EditProfile.this);
        StringRequest request = new StringRequest(Request.Method.POST, SessionManager.GET_PROFILE, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.has("status") && object.optBoolean("status")) {
                        JSONObject userObject = object.getJSONObject("user");
                        binding.editTextFirstNameEditProfile.setText(userObject.optString("first_name"));
                        binding.editTextLastNameEditProfile.setText(userObject.optString("last_name"));
                        binding.editTextDescriptionEditProfile.setText(SessionManager.checkNullString(userObject.optString("description")));
                        CircularProgressDrawable circularProgressDrawable = new CircularProgressDrawable(EditProfile.this);
                        circularProgressDrawable.setStrokeWidth(5f);
                        circularProgressDrawable.setCenterRadius(30f);
                        circularProgressDrawable.start();
                        String URL = SessionManager.STORAGE + userObject.optString("avatar");
                        Picasso.with(EditProfile.this).load(URL).placeholder(circularProgressDrawable).error(R.drawable.ic_user_placeholder).into(binding.imageViewUserEditPro);

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                custPrograssbar.closePrograssBar();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                custPrograssbar.closePrograssBar();
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> param = new HashMap<>();
                param.put("provider_id",manager.getUserId());
                return param;
            }
        };
        MySingleton.getInstance(EditProfile.this).addToRequestQueue(request);
    }

    private void updateNewProfile() {
        custPrograssbar.prograssCreate(EditProfile.this);
        StringRequest request = new StringRequest(Request.Method.POST, SessionManager.UPDATE_PROFILE, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.has("success") && object.optBoolean("success")) {
                        new ToastMessage(EditProfile.this).showSmallCustomToast("Profile update successfully");
                    } else if (object.has("error")) {
                        new ToastMessage(EditProfile.this).showSmallCustomToast(object.optString("error"));
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                custPrograssbar.closePrograssBar();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                custPrograssbar.closePrograssBar();
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> param = new HashMap<>();
                param.put("provider_id",manager.getUserId());
                param.put("first_name",binding.editTextFirstNameEditProfile.getText().toString());
                param.put("last_name",binding.editTextLastNameEditProfile.getText().toString());
                param.put("description",binding.editTextDescriptionEditProfile.getText().toString());
                param.put("address",binding.address.getText().toString());
                param.put("latitude",""+latLng.latitude);
                param.put("longitude",""+latLng.longitude);
                return param;
            }
        };
        MySingleton.getInstance(EditProfile.this).addToRequestQueue(request);
    }


    private void updateProfile() {
        custPrograssbar.prograssCreate(EditProfile.this);
        try {
            String uploadId = UUID.randomUUID().toString();
            //Creating a multi part request
            new MultipartUploadRequest(EditProfile.this, uploadId, SessionManager.UPDATE_PROFILE)
                    .addFileToUpload(filePath, "picture") //Adding file
                    .addParameter("provider_id", manager.getUserId()) //Adding file
                    .addParameter("first_name", binding.editTextFirstNameEditProfile.getText().toString())
                    .addParameter("last_name", binding.editTextLastNameEditProfile.getText().toString())
                    .addParameter("latitude", ""+latLng.latitude)
                    .addParameter("longitude", ""+latLng.longitude)
                    .addParameter("address", binding.address.getText().toString())
                    .addParameter("description", binding.editTextDescriptionEditProfile.getText().toString())//Adding file
                    .setDelegate(new UploadStatusDelegate() {
                        @Override
                        public void onProgress(Context context, UploadInfo uploadInfo) {
                        }

                        @Override
                        public void onError(Context context, UploadInfo uploadInfo, ServerResponse serverResponse, Exception exception) {
                            new ToastMessage(EditProfile.this).showSmallCustomToast("Data Error" + exception);
                            custPrograssbar.closePrograssBar();
                        }

                        @Override
                        public void onCompleted(Context context, UploadInfo uploadInfo, ServerResponse serverResponse) {
                            // new ToastMessage(EditProfile.this).showSmallCustomToast(""+serverResponse.getBodyAsString());
                            custPrograssbar.closePrograssBar();

                            try {
                                JSONObject object = new JSONObject(serverResponse.getBodyAsString());
                                if (object.has("success") && object.optBoolean("success")) {
                                    new ToastMessage(EditProfile.this).showSmallCustomToast("Profile update successfully");
                                } else if (object.has("error")) {
                                    new ToastMessage(EditProfile.this).showSmallCustomToast(object.optString("error"));
                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }

                        @Override
                        public void onCancelled(Context context, UploadInfo uploadInfo) {
                            custPrograssbar.closePrograssBar();
                            new ToastMessage(EditProfile.this).showSmallCustomToast("Something went wrong");

                        }

                    })
                    .setMaxRetries(1)
                    .startUpload(); //Starting the upload


        } catch (Exception exc) {
            new ToastMessage(EditProfile.this).showSmallCustomToast(exc.getMessage());
        }
    }
}
