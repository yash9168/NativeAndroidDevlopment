package com.socspl.provider.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.gson.JsonObject;
import com.socspl.provider.R;
import com.socspl.provider.databinding.ActivityLoginBinding;
import com.socspl.provider.retrofit.APIClient;
import com.socspl.provider.retrofit.GetResult;
import com.socspl.provider.util.CustPrograssbar;
import com.socspl.provider.util.MySingleton;
import com.socspl.provider.util.SessionManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import retrofit2.Call;

public class LoginActivity extends AppCompatActivity {
    ActivityLoginBinding binding;

    CustPrograssbar custPrograssbar;
    SessionManager sessionManager;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_login);

        requestPermissions(new String[]{Manifest.permission.CALL_PHONE, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        custPrograssbar = new CustPrograssbar();
        sessionManager = new SessionManager(LoginActivity.this);

        binding.txtLogin.setOnClickListener(v -> {
            if (validation()) {
                loginUser();
            }
        });
    }

    private void loginUser() {
        custPrograssbar.prograssCreate(LoginActivity.this);
        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(new OnCompleteListener<String>() {
                    @Override
                    public void onComplete(@NonNull Task<String> task) {

                        if (!task.isSuccessful()) {
                            return;
                        }
                        // Get new FCM registration token
                        String token = task.getResult();

                        StringRequest request = new StringRequest(Request.Method.POST, SessionManager.LOGIN, new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    JSONObject object = new JSONObject(response).getJSONObject("user");

                                    String id = object.optString("id");
                                    String email = object.optString("email");
                                    String f_name = object.optString("first_name");
                                    String l_name = object.optString("last_name");
                                    String picture = SessionManager.checkNullString( object.optString("picture"));
                                    String mobile = SessionManager.checkNullString( object.optString("mobile"));
                                    String status = ""+ object.optInt("status");
                                    new SessionManager(LoginActivity.this).setData(""+id,""+f_name,""+l_name,""+email,""+mobile,""+picture,status,"");

                                    startActivity(new Intent(LoginActivity.this, MainScreen.class)
                                            .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK));
                                    finishAffinity();
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                custPrograssbar.closePrograssBar();
                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                custPrograssbar.closePrograssBar();
                            }
                        }){
                            @Override
                            protected Map<String, String> getParams() throws AuthFailureError {
                                HashMap<String, String> jsonObject = new HashMap<>();
                                jsonObject.put("email", binding.edEmail.getText().toString());
                                jsonObject.put("password", binding.edPasssword.getText().toString());
                                jsonObject.put("device_token", token);
                                jsonObject.put("device_type", "android");
                                jsonObject.put("device_id", getDeviceId());
                                return jsonObject;
                            }
                        };

                        MySingleton.getInstance(LoginActivity.this).addToRequestQueue(request);

                    }
                });

    }

    public boolean validation() {
        if (TextUtils.isEmpty(binding.edEmail.getText().toString())) {
            binding.edEmail.setError("Enter Email");
            return false;
        }
        if (TextUtils.isEmpty(binding.edPasssword.getText().toString())) {
            binding.edPasssword.setError("Enter Password");
            return false;
        }
        return true;
    }

    //get device id
    @SuppressLint("HardwareIds")
    public String getDeviceId() {
        String deviceId;
        try {
            deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        } catch (Exception e) {
            deviceId = "NotFound";
        }
        return deviceId;
    }
}


