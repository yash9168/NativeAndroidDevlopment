package com.socspl.provider.activity;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.socspl.provider.R;
import com.socspl.provider.service.CallNotificationService;
import com.socspl.provider.util.CustPrograssbar;
import com.socspl.provider.util.MySingleton;
import com.socspl.provider.util.SessionManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import dev.shreyaspatil.MaterialDialog.MaterialDialog;

public class MainScreen extends AppCompatActivity {
    private MaterialDialog mAnimatedDialog;
    SessionManager manager;
    CustPrograssbar custPrograssbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
            KeyguardManager keyguardManager = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
            keyguardManager.requestDismissKeyguard(this, null);
        }
        else{
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        setContentView(R.layout.activity_main_screen);

        Intent intent = getIntent();

        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.providerPageFragment, R.id.providerUpcomingFragment, R.id.providerCompleteFragment,R.id.providerManageFragment,R.id.providerProfileFragment)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        manager = new SessionManager(MainScreen.this);
        custPrograssbar = new CustPrograssbar();
//        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);
        if (intent != null) {
            if (intent.hasExtra("name") && intent.hasExtra("request_id")) {
                mAnimatedDialog = new MaterialDialog.Builder(MainScreen.this)
                        .setTitle("Incoming Request")
                        .setMessage(intent.getStringExtra("name"))
                        .setCancelable(false)
                        .setPositiveButton("Accept", R.drawable.ic_baseline_accept, (dialogInterface, i) -> {
                            acceptRequest(manager.getUserId(), intent.getStringExtra("request_id"));
                            dialogInterface.dismiss();

                        }).setNegativeButton("Reject", R.drawable.ic_baseline_reject , (dialogInterface, i) -> {
                            rejectRequest(manager.getUserId(), intent.getStringExtra("request_id"));
                            dialogInterface.dismiss();
                })
                        .setAnimation(R.raw.incoming_call)
                        .build();

                mAnimatedDialog.show();
            } else {
                checkIncomingServices();
            }
        }

    }

    private void checkIncomingServices() {

        StringRequest request = new StringRequest(Request.Method.GET, SessionManager.INCOMING + manager.getUserId(), new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object1 = new JSONObject(response);
                    JSONArray array = object1.getJSONArray("requests");
                    if (array.length() > 0) {
                        Intent intent = new Intent(MainScreen.this, ServiceDetailActivity.class);
                        intent.putExtra("data", response);
                        startActivity(intent);
                    }
                } catch (JSONException e) {
                    Log.d("PastError ",""+e.getStackTrace());
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> map = new HashMap<>();
                map.put("provider_id",manager.getUserId());
                return map;
            }
        };
        MySingleton.getInstance(MainScreen.this).addToRequestQueue(request);
    }

    private void rejectRequest(String user_id, String request_id) {
        Intent iclose = new Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
        stopService(new Intent(this, CallNotificationService.class));
        custPrograssbar.prograssCreate(MainScreen.this);
        StringRequest request = new StringRequest(Request.Method.POST, SessionManager.REJECT_REQUEST, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.has("error"))
                        SessionManager.showToast(MainScreen.this, object.optString("error"));

                    if (object.has("success") && object.optBoolean("success")) {
                        SessionManager.showToast(MainScreen.this, "Request has been rejected successfully");
                        mAnimatedDialog.dismiss();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                custPrograssbar.closePrograssBar();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                custPrograssbar.closePrograssBar();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> jsonObject = new HashMap<>();
                jsonObject.put("provider_id", user_id);
                jsonObject.put("request_id", request_id);
                return jsonObject;
            }
        };

        MySingleton.getInstance(MainScreen.this).addToRequestQueue(request);
    }

    private void acceptRequest(String user_id, String request_id) {
        Intent iclose = new Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
        stopService(new Intent(this, CallNotificationService.class));
        custPrograssbar.prograssCreate(MainScreen.this);
        StringRequest request = new StringRequest(Request.Method.POST, SessionManager.ACCEPT_REQUEST, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.has("error"))
                        SessionManager.showToast(MainScreen.this, object.optString("error"));

                    if (object.has("status") && object.optBoolean("status")) {
                        SessionManager.showToast(MainScreen.this, "Request has been accepted successfully");
                        mAnimatedDialog.dismiss();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                custPrograssbar.closePrograssBar();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                custPrograssbar.closePrograssBar();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> jsonObject = new HashMap<>();
                jsonObject.put("provider_id", user_id);
                jsonObject.put("request_id", request_id);
                return jsonObject;
            }
        };

        MySingleton.getInstance(MainScreen.this).addToRequestQueue(request);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.top_option, menu);
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.logout) {

            new MaterialAlertDialogBuilder(MainScreen.this)
                    .setTitle(getString(R.string.app_name))
                    .setCancelable(false)
                    .setMessage("Are u sure want to logout")
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                            new SessionManager(MainScreen.this).clearData();
//                            clearApplicationData();
                            finish();
                            startActivity(new Intent(MainScreen.this, LoginActivity.class));
                        }
                    })
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .show();

        }
        return true;
    }

}