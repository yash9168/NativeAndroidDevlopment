package com.socspl.provider.activity;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.swiperefreshlayout.widget.CircularProgressDrawable;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.canhub.cropper.CropImage;
import com.genie.spinner.MaterialSpinner;
import com.google.gson.Gson;
import com.sanjaya.dialogspinner.DialogSpinner;
import com.socspl.provider.R;
import com.socspl.provider.adapter.AdditionalInfoAdapter;
import com.socspl.provider.databinding.ActivityServiceDescriptionBinding;
import com.socspl.provider.model.EndServiceModel;
import com.socspl.provider.model.InvoiceType;
import com.socspl.provider.model.SparePartsModel;
import com.socspl.provider.util.CustPrograssbar;
import com.socspl.provider.util.MySingleton;
import com.socspl.provider.util.SessionManager;
import com.socspl.provider.util.ToastMessage;
import com.squareup.picasso.Picasso;

import net.gotev.uploadservice.MultipartUploadRequest;
import net.gotev.uploadservice.ServerResponse;
import net.gotev.uploadservice.UploadInfo;
import net.gotev.uploadservice.UploadStatusDelegate;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ServiceDetailActivity extends AppCompatActivity {
    ActivityServiceDescriptionBinding binding;
    String request_id;
    CustPrograssbar custPrograssbar;
    private Uri path1;
    SessionManager manager;
    String file_path;
    private RadioButton radioSexButton;
    private double  lats;
    private double  longs;
    String paymentMode = "CASH";
    AlertDialog.Builder builder;
    AlertDialog dialog;
    AdditionalInfoAdapter adapter;
    private ArrayList<InvoiceType> additionInfoList = new ArrayList<>();
    private ArrayList<InvoiceType> spareInfoList = new ArrayList<>();
    int price = 0;
    int paid_amount = 0;

    MaterialSpinner spin_select_parts;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_service_description);
        binding.topAppBar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        manager = new SessionManager(ServiceDetailActivity.this);
        custPrograssbar = new CustPrograssbar();
        Bundle bundle = getIntent().getExtras();

        if (bundle!= null){
            updateIncomingStatus(bundle.getString("data"));
        }

        binding.txtSubmit.setOnClickListener(v -> {
            if (!TextUtils.isEmpty(binding.edtOtp.getText().toString())) {
                checkOtp();
            } else
                SessionManager.showToast(ServiceDetailActivity.this, "Missing otp");
        });

        binding.paymentMode.setOnClickListener(v -> {
            ArrayList<String> arrayList=new ArrayList<>();
            arrayList.add("Cash");
            arrayList.add("Online");

            DialogSpinner.show(ServiceDetailActivity.this,"Select payment mode",arrayList,binding.paymentMode);
        });

        binding.txtArrived.setOnClickListener(v -> {
            updateStatus("arrived");
        });

        binding.imageButton.setOnClickListener(v -> {
            CropImage.activity()
                    .start( this);
        });

        binding.afterImageButton.setOnClickListener(v -> {
            CropImage.activity()
                    .start( this);
        });

        binding.txtBeforeSubmit.setOnClickListener(v -> {
            if (!TextUtils.isEmpty(binding.edtComment.getText()) && !TextUtils.isEmpty(file_path))
                updateImage("before_image", file_path, "PICKEDUP","before_comment", binding.edtComment.getText().toString(), "");

            else if (TextUtils.isEmpty(file_path))
                updateServiceStatus( "PICKEDUP","before_comment", binding.edtComment.getText().toString(), "");
            else
                new ToastMessage(ServiceDetailActivity.this).showSmallCustomToast("Please enter comment");
        });

        binding.txtAfterSubmit.setOnClickListener(v -> {
            int selectedId=binding.radioGroup.getCheckedRadioButtonId();
            radioSexButton = findViewById(selectedId);

            if (!TextUtils.isEmpty(binding.edtAfterComment.getText()) && !TextUtils.isEmpty(file_path))
                updateImage("after_image", file_path, "DROPPED","after_comment", binding.edtAfterComment.getText().toString(), radioSexButton.getText().toString().equalsIgnoreCase("online") ? "CARD" : "CASH");


            else if (TextUtils.isEmpty(file_path)) {
                if (additionInfoList != null && additionInfoList.size() > 0) {
                    submitRequestData(getRequestedData());
                } else {
                    updateServiceStatus( "DROPPED","after_comment", binding.edtAfterComment.getText().toString(), radioSexButton.getText().toString().equalsIgnoreCase("online") ? "CARD" : "CASH");
                }
            } else
                new ToastMessage(ServiceDetailActivity.this).showSmallCustomToast("Please enter comment");
        });

        binding.review.setOnClickListener(v -> {
            if (!TextUtils.isEmpty(binding.reviewBox.getText()))
                rateUser();
            else
                new ToastMessage(ServiceDetailActivity.this).showSmallCustomToast("Please enter review");
        });

        binding.txtPaid.setOnClickListener(v -> {
            updatePaymentStatus("completed", paymentMode);
        });

        binding.txtMap.setOnClickListener(v -> {
            startActivity(new Intent(this, ViewMapActivity.class).putExtra("lat", lats).putExtra("longs", longs));

        });

        binding.radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            switch (checkedId) {
                case R.id.radioButton:
                    updatePaymentMode("CASH");
                    break;
                case R.id.radioButton2:
                    updatePaymentMode("CARD");
                    break;
            }
        });

        adapter = new AdditionalInfoAdapter(ServiceDetailActivity.this, additionInfoList, new AdditionalInfoAdapter.ItemClickListener() {
            @Override
            public void onItemSelected(int position, InvoiceType model) {
                insertAdditionalCharges(position, model, "update", "ADDITIONAL_INFO");
            }

            @Override
            public void removeItem(int position) {
                if (additionInfoList != null && additionInfoList.size() == 1) {
                    binding.price.setText(getString(R.string.rupees) + price);
                }
                additionInfoList.remove(position);
                adapter.notifyDataSetChanged();
                if (additionInfoList != null && additionInfoList.size() > 0) {
                    paid_amount = 0;
                    for (InvoiceType value: additionInfoList) {
                        if (value.getPaid_amount() != null) {
                            paid_amount += Integer.parseInt(value.getPaid_amount());
                        }
                    }
                    int real_amount = price + paid_amount;
                    binding.price.setText(getString(R.string.rupees) + real_amount);

                }
            }
        });

        binding.recycler.setHasFixedSize(false);
        binding.recycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        binding.recycler.setItemAnimator(new DefaultItemAnimator());
        binding.recycler.setAdapter(adapter);

        binding.addCharges.setOnClickListener(v -> {
            InvoiceType invoiceType = new InvoiceType();
            insertAdditionalCharges(0, invoiceType, "add", "ADDITIONAL_INFO");

        });

        binding.addSpareParts.setOnClickListener(v -> {
            InvoiceType invoiceType = new InvoiceType();
            insertAdditionalCharges(0, invoiceType, "add", "SPARE_PARTS");
        });

        binding.txtAddMore.setOnClickListener(v -> {
            InvoiceType invoiceType = new InvoiceType();
            insertAdditionalCharges(0, invoiceType, "add", "SPARE_PARTS");
        });

    }

    private EndServiceModel getRequestedData() {
        EndServiceModel model = new EndServiceModel();
        model.setRequest_id(request_id);
        model.setAfter_comment(binding.edtAfterComment.getText().toString());
        model.setStatus("DROPPED");
        model.setPayment_mode(radioSexButton.getText().toString().equalsIgnoreCase("online") ? "CARD" : "CASH");
        if (additionInfoList != null && additionInfoList.size() > 0) {
            model.setInvoice_type(additionInfoList);
        }
        return model;
    }

    private void insertAdditionalCharges(int position, InvoiceType userData, String type, String newType) {
        builder = new AlertDialog.Builder(ServiceDetailActivity.this);
        if (type.equalsIgnoreCase("update")) {
            builder.setTitle("Update Charges");
        } else {
            builder.setTitle("Insert Charges");
        }
        builder.setCancelable(false);
        View view = LayoutInflater.from(ServiceDetailActivity.this).inflate(R.layout.dialog_additional_info,null,false);
        InitUpdateAdditionalChargesDialog(position,view, type, userData, newType);
        builder.setView(view);
        dialog = builder.create();
        dialog.show();
    }
    AppCompatEditText edt_remarks, edt_actual_amount, edt_paid_amount;
    Button btn_update, btn_cancel;
    String actual_amount;
    private void InitUpdateAdditionalChargesDialog(final int position, View view, final String type, InvoiceType userData, String newType) {

        edt_remarks = view.findViewById(R.id.edt_remarks);
        spin_select_parts = view.findViewById(R.id.spin_select_parts);
        edt_actual_amount = view.findViewById(R.id.edt_actual_amount);
        edt_paid_amount = view.findViewById(R.id.edt_paid_amount);
        btn_update = view.findViewById(R.id.btn_update_user);
        btn_cancel = view.findViewById(R.id.btn_update_cancel);
        if (newType.equalsIgnoreCase("ADDITIONAL_INFO")) {
            spin_select_parts.setVisibility(View.GONE);
            edt_remarks.setVisibility(View.VISIBLE);
        } else {
            spin_select_parts.setVisibility(View.VISIBLE);
            edt_remarks.setVisibility(View.GONE);
            getSpareParts();


        }

        if (userData != null) {
            if (userData.getInvoice_type() != null) {
                if (newType.equalsIgnoreCase("ADDITIONAL_INFO"))
                    edt_remarks.setText(userData.getInvoice_type());
                else {
                    if (itemList != null && itemList.size() > 0) {
                        for (int i = 0; i < itemList.size(); i++) {
                            if (userData != null && userData.getInvoice_type() != null) {
                                if (itemList.get(i).equalsIgnoreCase(userData.getInvoice_type())) {
                                    spin_select_parts.setSelection(i + 1);
                                }
                            }
                        }
                    }
                }
            }

            if (userData.getActual_amount() != null) {
                edt_actual_amount.setText(userData.getActual_amount());
            }

            if (userData.getPaid_amount() != null) {
                edt_paid_amount.setText(userData.getPaid_amount());
            }
        }
        btn_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (type.equalsIgnoreCase("update")) {
                    InvoiceType userData = new InvoiceType();
                    if (newType.equalsIgnoreCase("ADDITIONAL_INFO")) {
                        if (!TextUtils.isEmpty(edt_remarks.getText().toString()))
                            userData.setInvoice_type(edt_remarks.getText().toString());
                        else
                            edt_remarks.requestFocus();
                    } else {
                        if (spin_select_parts.getSelectedItemPosition() > 0) {
                            userData.setInvoice_type(spin_select_parts.getItemAtPosition(spin_select_parts.getSelectedItemPosition() -1).toString());
                        } else {
                            spin_select_parts.requestFocus();
                        }
                    }


                    if (!TextUtils.isEmpty(edt_actual_amount.getText().toString()))
                        userData.setActual_amount(edt_actual_amount.getText().toString());
                    else
                        edt_actual_amount.requestFocus();

                    if (!TextUtils.isEmpty(edt_paid_amount.getText().toString()))
                        userData.setPaid_amount(edt_paid_amount.getText().toString());
                    else
                        edt_paid_amount.requestFocus();

                    additionInfoList.set(position, userData);
                    adapter.notifyItemChanged(position);
                    dialog.dismiss();
                    if (additionInfoList != null && additionInfoList.size() > 0) {
                        paid_amount = 0;
                        for (InvoiceType value: additionInfoList) {
                            if (value.getPaid_amount() != null) {
                                paid_amount += Integer.parseInt(value.getPaid_amount());
                            }
                        }
                        int real_amount = price + paid_amount;
                        binding.price.setText(getString(R.string.rupees) + real_amount);

                    }
                } else {
                    InvoiceType userData = new InvoiceType();
                    if (newType.equalsIgnoreCase("ADDITIONAL_INFO")) {
                        if (!TextUtils.isEmpty(edt_remarks.getText().toString()))
                            userData.setInvoice_type(edt_remarks.getText().toString());
                        else {
                            edt_remarks.requestFocus();
                            edt_remarks.setError("Missing Remarks");
                            return;
                        }
                    } else {
                        if (spin_select_parts.getSelectedItemPosition() == -1) {
                            spin_select_parts.requestFocus();
                            return;
                        } else {
                            userData.setInvoice_type(spin_select_parts.getItemAtPosition(spin_select_parts.getSelectedItemPosition() -1).toString());
                        }
                    }


                    if (!TextUtils.isEmpty(edt_actual_amount.getText().toString()))
                        userData.setActual_amount(edt_actual_amount.getText().toString());
                    else {
                        edt_actual_amount.requestFocus();
                        edt_actual_amount.setError("Missing Actual Amount");
                        return;
                    }

                    if (!TextUtils.isEmpty(edt_paid_amount.getText().toString()))
                        userData.setPaid_amount(edt_paid_amount.getText().toString());
                    else {
                        edt_paid_amount.requestFocus();
                        edt_paid_amount.setError("Missing Paid Amount");
                        return;
                    }

                    additionInfoList.add(userData);
                    adapter.notifyDataSetChanged();
                    dialog.dismiss();
                    if (additionInfoList != null && additionInfoList.size() > 0) {
                        paid_amount = 0;
                        for (InvoiceType value: additionInfoList) {
                            if (value.getPaid_amount() != null) {
                                paid_amount += Integer.parseInt(value.getPaid_amount());
                            }
                        }
                        int real_amount = price + paid_amount;
                        binding.price.setText(getString(R.string.rupees) + real_amount);

                    }
                }

            }
        });
        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
    }
    ArrayList<String> itemList;
    ArrayList<SparePartsModel> modelList;

    private void getSpareParts() {
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            JSONObject object = null;
            try {
                itemList = new ArrayList<>();
                modelList = new ArrayList<>();
                object = new JSONObject(bundle.getString("data"));
                JSONArray jsonarray = object.optJSONArray("ratecard");
                for (int i = 0; i < jsonarray.length(); i++) {
                    JSONObject jsonobject = jsonarray.getJSONObject(i);
                    SparePartsModel model  = new SparePartsModel();
                    model.setPrice(jsonobject.optString("price"));
                    model.setSpare_name(jsonobject.optString("spare_name"));
                    modelList.add(model);

                    itemList.add(jsonobject.optString("spare_name"));

                }
                spin_select_parts.setAdapter(new ArrayAdapter<String>(ServiceDetailActivity.this,
                        android.R.layout.simple_spinner_dropdown_item,
                        itemList));

                spin_select_parts.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(AdapterView<?> arg0,
                                               View arg1, int position, long arg3) {
                        if (modelList != null && modelList.size() > 0) {
                            if (position >= 0) {
                                actual_amount = modelList.get(position).getPrice();
                                edt_actual_amount.setText(actual_amount);
                            }
                        }
                        // TODO Auto-generated method stub

                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> arg0) {
                        // TODO Auto-generated method stub
                    }
                });
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

    }

    private void updatePaymentMode(String payMode) {
        custPrograssbar.prograssCreate(ServiceDetailActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, SessionManager.UPDATE_PAY_MODE, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                custPrograssbar.closePrograssBar();
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.has("status") && object.optBoolean("status")) {
                        SessionManager.showToast(ServiceDetailActivity.this, "Payment method updated successfully");
                    } else
                        SessionManager.showToast(ServiceDetailActivity.this, "Some error occurred while updating payment method");

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                custPrograssbar.closePrograssBar();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                custPrograssbar.closePrograssBar();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> jsonObject = new HashMap<>();
                jsonObject.put("request_id", request_id);
                jsonObject.put("pay_mode", payMode);
                return jsonObject;
            }
        };

        MySingleton.getInstance(ServiceDetailActivity.this).addToRequestQueue(request);
    }

    private void updateIncomingStatus(String data) {
        try {
            JSONObject object = new JSONObject(data);
            JSONArray array = object.getJSONArray("requests");
            JSONArray rateCardArray = object.optJSONArray("ratecard");
            JSONArray serviceDetArray = object.getJSONArray("service_details");
            JSONObject serviceDetObj = serviceDetArray.getJSONObject(0);
            JSONObject arrayObject = array.getJSONObject(0);
            JSONObject requestObject = arrayObject.getJSONObject("request");
            JSONObject userObject = requestObject.getJSONObject("user");
            JSONObject paymentRequest = requestObject.optJSONObject("payment");
            lats = requestObject.optDouble("s_latitude");
            longs = requestObject.optDouble("s_longitude");
            if (requestObject.optString("status").equalsIgnoreCase("Started")) {
                binding.linStartedLayout.setVisibility(View.VISIBLE);
                binding.linArrivedLayout.setVisibility(View.GONE);
            } else if (requestObject.optString("status").equalsIgnoreCase("Arrived") && requestObject.optInt("otp_matched") != 1) {
                binding.linStartedLayout.setVisibility(View.GONE);
                binding.linArrivedLayout.setVisibility(View.VISIBLE);
            } else if (requestObject.optString("status").equalsIgnoreCase("Arrived") && requestObject.optInt("otp_matched") == 1) {
                binding.linStartedLayout.setVisibility(View.GONE);
                binding.linArrivedLayout.setVisibility(View.GONE);
                binding.linBeforeLayout.setVisibility(View.VISIBLE);
            } else if (requestObject.optString("status").equalsIgnoreCase("PICKEDUP")) {
                binding.linStartedLayout.setVisibility(View.GONE);
                binding.linArrivedLayout.setVisibility(View.GONE);
                binding.linBeforeLayout.setVisibility(View.GONE);
                binding.linAfterLayout.setVisibility(View.VISIBLE);
            } else if (requestObject.optString("status").equalsIgnoreCase("DROPPED")) {
                binding.linStartedLayout.setVisibility(View.GONE);
                binding.linArrivedLayout.setVisibility(View.GONE);
                binding.linBeforeLayout.setVisibility(View.GONE);
                binding.linAfterLayout.setVisibility(View.GONE);
                binding.linCompleted.setVisibility(View.VISIBLE);
                paymentMode = requestObject.optString("payment_mode");
            } else if (requestObject.optString("status").equalsIgnoreCase("COMPLETED")) {
                binding.linStartedLayout.setVisibility(View.GONE);
                binding.linArrivedLayout.setVisibility(View.GONE);
                binding.linBeforeLayout.setVisibility(View.GONE);
                binding.linAfterLayout.setVisibility(View.GONE);
                binding.linReview.setVisibility(View.VISIBLE);
                binding.linCompleted.setVisibility(View.GONE);
            }
            binding.name.setText(userObject.optString("first_name") + " " + userObject.optString("last_name"));
            binding.walletBal.setText("Use wallet balance ("+ getString(R.string.rupees)+userObject.optString("wallet_balance") + ")");
            binding.txtLocation.setText(requestObject.optString("s_address"));
            binding.serviceName.setText(serviceDetObj.getJSONObject("child_category").optString("name"));
            request_id = requestObject.optString("id");
            binding.requestId.setText(request_id);
            price = Integer.parseInt(requestObject.getJSONObject("service_order").optString("fixed"));
            binding.price.setText(getString(R.string.rupees) + price);

            if (paymentRequest != null && paymentRequest.has("total")) {
                price = Integer.parseInt(paymentRequest.optString("total"));
                binding.price.setText(getString(R.string.rupees) + price);
            }
            CircularProgressDrawable circularProgressDrawable = new CircularProgressDrawable(this);
            circularProgressDrawable.setStrokeWidth(5f);
            circularProgressDrawable.setCenterRadius(30f);
            circularProgressDrawable.start();
            String URL = SessionManager.STORAGE +userObject.optString("picture");
            Picasso.with(this).load(URL).placeholder(circularProgressDrawable).error(R.drawable.ic_user_placeholder).into(binding.providerImage);

            if (rateCardArray.length() > 0) {
                binding.txtRateCard.setVisibility(View.VISIBLE);
                binding.txtRateCard.setOnClickListener(v -> {
                    Intent intent = new Intent(ServiceDetailActivity.this, ViewRateActivity.class);
                    intent.putExtra("data", data);
                    startActivity(intent);
                });
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {

            if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
                CropImage.ActivityResult result = CropImage.getActivityResult(data);
                if (resultCode == RESULT_OK) {
                    path1 = result.getUriContent();
                    String s = "" + result.getUriContent();
                    CircularProgressDrawable circularProgressDrawable = new CircularProgressDrawable(getApplicationContext());
                    circularProgressDrawable.setStrokeWidth(5f);
                    circularProgressDrawable.setCenterRadius(30f);
                    circularProgressDrawable.start();
                    String path_data = result.getUriFilePath(this, true);
                    if (binding.linBeforeLayout.getVisibility() == View.VISIBLE) {
                        Picasso.with(ServiceDetailActivity.this).load(path1).placeholder(circularProgressDrawable).into(binding.profileImage);
                    } else {
                        Picasso.with(ServiceDetailActivity.this).load(path1).placeholder(circularProgressDrawable).into(binding.profileAfterImage);
                    }
                    file_path = result.getUriFilePath(this, true);
//                    updateImage(result.getUriFilePath(this, true), "PICKEDUP");
                } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                    Exception error = result.getError();
                }
            }
        }
    }

    private void updateImage(String imgKey, String uriFilePath, String pickedup, String key_comment, String value_comment, String payment_mode) {
        custPrograssbar.prograssCreate(ServiceDetailActivity.this);
        try {
            String uploadId = UUID.randomUUID().toString();
            //Creating a multi part request
            new MultipartUploadRequest(this, uploadId, SessionManager.STATUS_UPDATE)
                    .addFileToUpload(uriFilePath, imgKey) //Adding file
                    .addParameter("status", pickedup.toUpperCase()) //Adding file
                    .addParameter("request_id", request_id) //Adding file
                    .addParameter(key_comment, value_comment)
                    .addParameter("payment_mode", payment_mode)//Adding file
                    .setDelegate(new UploadStatusDelegate() {
                        @Override
                        public void onProgress(Context context, UploadInfo uploadInfo) {
                        }

                        @Override
                        public void onError(Context context, UploadInfo uploadInfo, ServerResponse serverResponse, Exception exception) {
                            new ToastMessage(ServiceDetailActivity.this).showSmallCustomToast("Data Error" + exception);
                            custPrograssbar.closePrograssBar();
                        }

                        @Override
                        public void onCompleted(Context context, UploadInfo uploadInfo, ServerResponse serverResponse) {
                            // new ToastMessage(EditProfile.this).showSmallCustomToast(""+serverResponse.getBodyAsString());
                            custPrograssbar.closePrograssBar();

                            try {
                                JSONObject object = new JSONObject(serverResponse.getBodyAsString());
                                if (object.has("status") && object.optBoolean("status")) {
                                    checkIncomingServices();
                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }

                        @Override
                        public void onCancelled(Context context, UploadInfo uploadInfo) {
                            custPrograssbar.closePrograssBar();
                            new ToastMessage(ServiceDetailActivity.this).showSmallCustomToast("Something went wrong");

                        }

                    })
                    .setMaxRetries(1)
                    .startUpload(); //Starting the upload


        } catch (Exception exc) {
            new ToastMessage(this).showSmallCustomToast(exc.getMessage());
        }
    }

    private void checkOtp() {
        custPrograssbar.prograssCreate(ServiceDetailActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, SessionManager.CHECK_OTP, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                custPrograssbar.closePrograssBar();
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.getJSONObject("user").has("otp_matched") && object.getJSONObject("user").optInt("otp_matched") == 1) {
                        binding.linArrivedLayout.setVisibility(View.GONE);
                        binding.linStartedLayout.setVisibility(View.GONE);
                        binding.linBeforeLayout.setVisibility(View.VISIBLE);
                    } else
                        SessionManager.showToast(ServiceDetailActivity.this, "Incorrect otp");

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                custPrograssbar.closePrograssBar();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                custPrograssbar.closePrograssBar();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> jsonObject = new HashMap<>();
                jsonObject.put("id", request_id);
                jsonObject.put("otp", binding.edtOtp.getText().toString());
                return jsonObject;
            }
        };

        MySingleton.getInstance(ServiceDetailActivity.this).addToRequestQueue(request);
    }

    private void updateStatus(String status) {
        custPrograssbar.prograssCreate(ServiceDetailActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, SessionManager.STATUS_UPDATE, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                custPrograssbar.closePrograssBar();
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.has("status") && object.optBoolean("status")) {
                        checkIncomingServices();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                custPrograssbar.closePrograssBar();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                custPrograssbar.closePrograssBar();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> jsonObject = new HashMap<>();
                jsonObject.put("request_id", request_id);
                jsonObject.put("status", status.toUpperCase());
                return jsonObject;
            }
        };

        MySingleton.getInstance(ServiceDetailActivity.this).addToRequestQueue(request);
    }

    private void updatePaymentStatus(String status, String payment_mode) {
        custPrograssbar.prograssCreate(ServiceDetailActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, SessionManager.STATUS_UPDATE, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                custPrograssbar.closePrograssBar();
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.has("status") && object.optBoolean("status")) {
                        checkIncomingServices();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                custPrograssbar.closePrograssBar();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                custPrograssbar.closePrograssBar();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> jsonObject = new HashMap<>();
                jsonObject.put("request_id", request_id);
                jsonObject.put("status", status.toUpperCase());
                jsonObject.put("payment_mode", payment_mode);
                return jsonObject;
            }
        };

        MySingleton.getInstance(ServiceDetailActivity.this).addToRequestQueue(request);
    }

    private void submitRequestData(EndServiceModel requestedData) {
        custPrograssbar.prograssCreate(ServiceDetailActivity.this);
        final String requestBody = new Gson().toJson(requestedData);
        StringRequest stringRequest = new StringRequest(com.android.volley.Request.Method.POST,
                SessionManager.STATUS_INVOICE, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                custPrograssbar.closePrograssBar();
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.has("status") && object.optBoolean("status")) {
                        checkIncomingServices();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(ServiceDetailActivity.this,
                        error.toString(), Toast.LENGTH_LONG).show();
                custPrograssbar.closePrograssBar();
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json");
                return params;
            }
            @Override
            public byte[] getBody() throws AuthFailureError {
                try {
                    return requestBody == null ? null : requestBody.getBytes("utf-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    return null;
                }
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(ServiceDetailActivity.this);
        requestQueue.add(stringRequest);

        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {

            }
        });
    }

    private void updateServiceStatus(String status, String key_comment, String value_comment, String payment_mode) {
        custPrograssbar.prograssCreate(ServiceDetailActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, SessionManager.STATUS_UPDATE, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                custPrograssbar.closePrograssBar();
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.has("status") && object.optBoolean("status")) {
                        checkIncomingServices();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                custPrograssbar.closePrograssBar();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                custPrograssbar.closePrograssBar();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> jsonObject = new HashMap<>();
                jsonObject.put("request_id", request_id);
                jsonObject.put("status", status.toUpperCase());
                jsonObject.put(key_comment, value_comment);
                jsonObject.put("payment_mode", payment_mode);
                return jsonObject;
            }
        };

        MySingleton.getInstance(ServiceDetailActivity.this).addToRequestQueue(request);
    }
    private void checkIncomingServices() {

        StringRequest request = new StringRequest(Request.Method.GET, SessionManager.INCOMING + manager.getUserId(), new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object1 = new JSONObject(response);
                    JSONArray array = object1.getJSONArray("requests");
                    if (array.length() > 0) {
                        updateIncomingStatus(response);
                    }
                } catch (JSONException e) {
                    Log.d("PastError ",""+e.getStackTrace());
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> map = new HashMap<>();
                map.put("provider_id",manager.getUserId());
                return map;
            }
        };
        MySingleton.getInstance(ServiceDetailActivity.this).addToRequestQueue(request);
    }

    private void rateUser() {
        custPrograssbar.prograssCreate(ServiceDetailActivity.this);
        int count = (int) binding.ratingBar.getRating();
        StringRequest request = new StringRequest(Request.Method.POST, SessionManager.RATE_USER, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                custPrograssbar.closePrograssBar();
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.has("status") && object.optBoolean("status"))
                        startActivity(new Intent(ServiceDetailActivity.this, MainScreen.class));
                    else
                        new ToastMessage(ServiceDetailActivity.this).showSmallCustomToast("Something went wrong");

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                custPrograssbar.closePrograssBar();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                custPrograssbar.closePrograssBar();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> jsonObject = new HashMap<>();
                jsonObject.put("request_id", request_id);
                jsonObject.put("rating", Integer.toString((int) binding.ratingBar.getRating()));
                jsonObject.put("comment", binding.reviewBox.getText().toString());
                return jsonObject;
            }
        };

        MySingleton.getInstance(ServiceDetailActivity.this).addToRequestQueue(request);
    }
}
