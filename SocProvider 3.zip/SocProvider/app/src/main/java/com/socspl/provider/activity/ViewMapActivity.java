package com.socspl.provider.activity;

import android.annotation.SuppressLint;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.Task;
import com.socspl.provider.R;
import com.socspl.provider.databinding.ActivityMapBinding;
import com.socspl.provider.interfaces.FetchURL;
import com.socspl.provider.interfaces.TaskLoadedCallback;

import static com.google.android.gms.location.LocationServices.getFusedLocationProviderClient;

public class ViewMapActivity extends AppCompatActivity implements OnMapReadyCallback, TaskLoadedCallback {
    ActivityMapBinding binding;
    private GoogleMap mMap;
    private MarkerOptions place1;
    private MarkerOptions  place2;
    Button getDirection;
    private Polyline currentPolyline;
    private FusedLocationProviderClient fusedLocationProviderClient;
    Double lat=0.0;
    Double longs=0.0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_map);

        binding.topAppBar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        fusedLocationProviderClient = getFusedLocationProviderClient(this);
        lat=getIntent().getDoubleExtra("lat",0.0);
        longs=getIntent().getDoubleExtra("longs",0.0);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        Log.d("mylog", "Added Markers");

        @SuppressLint("MissingPermission")
        Task<Location> lastLocation = fusedLocationProviderClient.getLastLocation();
        lastLocation.addOnSuccessListener(this, location -> {
            if (location != null) {

                Log.e("lat","-->"+location.getLatitude());
                Log.e("lot","-->"+location.getLongitude());
                place1 = new MarkerOptions().position(new LatLng(location.getLatitude(), location.getLongitude())).title("Location 1").icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_map));
                place2 = new MarkerOptions().position(new LatLng(lat, longs)).title("Location 2");
                new FetchURL(ViewMapActivity.this).execute(getUrl(place1.getPosition(), place2.getPosition(), "driving"), "driving");
                LatLng coordinate = new LatLng(location.getLatitude(), location.getLongitude());
                CameraUpdate yourLocation = CameraUpdateFactory.newLatLngZoom(coordinate, 17);
                mMap.animateCamera(yourLocation);
                mMap.addMarker(place1);
                mMap.addMarker(place2);

            } else {
                //Gps not enabled if loc is null

                Toast.makeText(ViewMapActivity.this, "Location not Available", Toast.LENGTH_SHORT).show();

            }
        });
        lastLocation.addOnFailureListener(e -> Toast.makeText(ViewMapActivity.this, "Location Not Availabe", Toast.LENGTH_SHORT).show());
    }

    private String getUrl(LatLng origin, LatLng dest, String directionMode) {
        // Origin of route
        String strOrigin = "origin=" + origin.latitude + "," + origin.longitude;
        // Destination of route
        String strDest = "destination=" + dest.latitude + "," + dest.longitude;
        // Mode
        String mode = "mode=" + directionMode;
        // Building the parameters to the web service
        String parameters = strOrigin + "&" + strDest + "&" + mode;
        // Output format
        String output = "json";
        // Building the url to the web service
        String url = "https://maps.googleapis.com/maps/api/directions/" + output + "?" + parameters + "&key=" + getString(R.string.api_key);
        return url;
    }

    @Override
    public void onTaskDone(Object... values) {
        if (currentPolyline != null)
            currentPolyline.remove();
        currentPolyline = mMap.addPolyline((PolylineOptions) values[0]);
    }
}
