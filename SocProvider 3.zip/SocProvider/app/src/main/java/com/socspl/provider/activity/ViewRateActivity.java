package com.socspl.provider.activity;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.socspl.provider.R;
import com.socspl.provider.adapter.ViewRateAdapter;
import com.socspl.provider.databinding.ActivityViewRateBinding;
import com.socspl.provider.util.MySingleton;
import com.socspl.provider.util.SessionManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ViewRateActivity extends AppCompatActivity {

    ActivityViewRateBinding binding;
    private ArrayList<JSONObject> listViewRate ;
    ViewRateAdapter viewRateAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding =  DataBindingUtil.setContentView(this, R.layout.activity_view_rate);

        binding.topAppBar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        listViewRate = new ArrayList<>();
        binding.recycler.setHasFixedSize(true);
        binding.recycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        // binding.category.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL,false));
        viewRateAdapter = new ViewRateAdapter(this, listViewRate);
        binding.recycler.setAdapter(viewRateAdapter);

        Bundle  bundle = getIntent().getExtras();

        if (bundle != null){
            JSONObject object = null;
            try {
                object = new JSONObject(bundle.getString("data"));
                JSONArray array = object.optJSONArray("ratecard");
                for (int i = 0; i <array.length() ; i++) {
                    listViewRate.add( array.getJSONObject(i));
                }
                if (listViewRate != null && listViewRate.size() >0)
                    viewRateAdapter.notifyDataSetChanged();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
