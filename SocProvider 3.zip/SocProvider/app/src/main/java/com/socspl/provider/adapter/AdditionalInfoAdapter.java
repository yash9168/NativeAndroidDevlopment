package com.socspl.provider.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.socspl.provider.R;
import com.socspl.provider.databinding.ItemAdditionalInfoBinding;
import com.socspl.provider.databinding.ItemViewRateBinding;
import com.socspl.provider.model.InvoiceType;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class AdditionalInfoAdapter extends RecyclerView.Adapter<AdditionalInfoAdapter.ViewRateHolder> {

    class ViewRateHolder extends RecyclerView.ViewHolder{
        ItemAdditionalInfoBinding binding;
        public ViewRateHolder(@NonNull ItemAdditionalInfoBinding itemView) {
            super(itemView.getRoot());
            binding = itemView;
        }
    }

    Context context ;
    List<InvoiceType> list;
    ItemClickListener listener;
    public AdditionalInfoAdapter(Context context, List<InvoiceType> list, ItemClickListener listener){
        this.context = context ;
        this.list = list ;
        this.listener = listener;
    }
    @NonNull
    @Override
    public AdditionalInfoAdapter.ViewRateHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemAdditionalInfoBinding binding =  DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_additional_info,parent,false);
        return new AdditionalInfoAdapter.ViewRateHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull AdditionalInfoAdapter.ViewRateHolder holder, int position) {
        final InvoiceType directionModel = list.get(position);
            if (directionModel != null) {
                if (directionModel.getInvoice_type() != null)
                    holder.binding.edtRemarks.setText(directionModel.getInvoice_type());

                if (directionModel.getActual_amount() != null)
                    holder.binding.edtActualAmount.setText(directionModel.getActual_amount());

                if (directionModel.getPaid_amount() != null)
                    holder.binding.edtPaidAmount.setText(directionModel.getPaid_amount());
            }

            holder.binding.deleteBtn.setOnClickListener(v -> {
                if (listener != null) {
                    listener.removeItem(position);
                }
            });

        holder.binding.rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (listener != null) {
                    listener.onItemSelected(position, directionModel);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        if (list != null && list.size() > 0) {
            return list.size();
        } else
            return 0;
    }
    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    public void setData(List<InvoiceType> gdbChHomeNativeLayoutList) {
        if (gdbChHomeNativeLayoutList != null && gdbChHomeNativeLayoutList.size() > 0) {
            this.list = gdbChHomeNativeLayoutList;
            notifyDataSetChanged();
        }
    }

    public void removeAt(int adapterPosition) {
        list.remove(adapterPosition);
        notifyItemRemoved(adapterPosition);
//        notifyItemRangeChanged(adapterPosition,list.size());
    }

    public void UpdateData(int position,InvoiceType userData){
        list.remove(position);
        list.add(userData);
        notifyItemChanged(position);
    }

    public interface ItemClickListener {
        void onItemSelected(int position, InvoiceType model);
        void removeItem(int position);
    }

}


