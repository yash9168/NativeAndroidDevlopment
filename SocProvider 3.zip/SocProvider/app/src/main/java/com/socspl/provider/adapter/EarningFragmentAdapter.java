package com.socspl.provider.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.socspl.provider.R;
import com.socspl.provider.databinding.AdapterTrazectionBinding;
import com.socspl.provider.util.SessionManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class EarningFragmentAdapter extends RecyclerView.Adapter<EarningFragmentAdapter.PastServiceHolder> {

    class  PastServiceHolder extends RecyclerView.ViewHolder{

        public AdapterTrazectionBinding binding ;
        public PastServiceHolder(@NonNull AdapterTrazectionBinding itemView) {
            super(itemView.getRoot());
            this.binding = itemView ;
        }
    }

    public Context context;
    public ArrayList<JSONObject> list;
    public String TYPE;
    public EarningFragmentAdapter(Context context, ArrayList<JSONObject> list, String TYPE){
        this.context = context;
        this.list = list;
        this.TYPE = TYPE;
    }



    @NonNull
    @Override
    public EarningFragmentAdapter.PastServiceHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        AdapterTrazectionBinding binding =  DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.adapter_trazection,parent,false);
        return new EarningFragmentAdapter.PastServiceHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull EarningFragmentAdapter.PastServiceHolder holder, int position) {
        if (list != null) {
            if (list.get(position).has("payment") && !TextUtils.isEmpty(list.get(position).optString("payment")) && list.get(position).optJSONObject("payment") != null) {
                double total = 0;
                double total_value = 0;
                JSONObject paymentObject = list.get(position).optJSONObject("payment");
                if (paymentObject.has("provider_commision_additional"))
                    total = paymentObject.optDouble("provider_commision_additional");
                double d = paymentObject.optDouble("provider_commision");
//                double i = Integer.valueOf(D.intValue());
                 total_value = total + d;
                holder.binding.txtAmount.setText(context.getString(R.string.rupees) +new DecimalFormat("##.##").format(total_value));
            }

            holder.binding.txtTital.setText(list.get(position).optString("booking_id"));
            if (list.get(position).has("service_order") && !TextUtils.isEmpty(list.get(position).optString("service_order")) && list.get(position).optJSONObject("service_order") != null) {
                    if (list.get(position).optJSONObject("service_order").has("order_details")) {
                        if (list.get(position).optJSONObject("service_order").optJSONObject("order_details").has("category"))
                        holder.binding.serviceType.setText(list.get(position).optJSONObject("service_order").optJSONObject("order_details").optJSONObject("category").optString("name"));
                    }
            }


            String finished_at =  list.get(position).optString("schedule_at");

            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            try {
                Date date = format.parse(finished_at);
                String complete_date = (String) DateFormat.format("dd/MM/yyyy - hh:mm", date);
                holder.binding.txtDate.setText(complete_date);
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
    }


    @Override
    public int getItemCount() {
        return list.size();
    }
    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }
}

