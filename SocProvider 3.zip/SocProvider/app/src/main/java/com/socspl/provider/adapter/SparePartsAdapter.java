package com.socspl.provider.adapter;

public class SparePartsAdapter {
}
