package com.socspl.provider.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.CircularProgressDrawable;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.socspl.provider.R;
import com.socspl.provider.activity.MainScreen;
import com.socspl.provider.databinding.LayoutPastServiceBinding;
import com.socspl.provider.util.MySingleton;
import com.socspl.provider.util.SessionManager;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class UpcomingServiceAdapter extends RecyclerView.Adapter<UpcomingServiceAdapter.PastServiceHolder> {

    class  PastServiceHolder extends RecyclerView.ViewHolder{

        public LayoutPastServiceBinding binding ;
        public PastServiceHolder(@NonNull LayoutPastServiceBinding itemView) {
            super(itemView.getRoot());
            this.binding = itemView ;
        }
    }

    public Context context;
    public ArrayList<JSONObject> list;
    public String TYPE;
    public UpcomingServiceAdapter(Context context, ArrayList<JSONObject> list, String TYPE){
        this.context = context;
        this.list = list;
        this.TYPE = TYPE;
    }



    @NonNull
    @Override
    public UpcomingServiceAdapter.PastServiceHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutPastServiceBinding binding =  DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.layout_past_service,parent,false);
        return new UpcomingServiceAdapter.PastServiceHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull UpcomingServiceAdapter.PastServiceHolder holder, int position) {
        holder.binding.contact.setVisibility(View.VISIBLE);
        CircularProgressDrawable circularProgressDrawable = new CircularProgressDrawable(context);
        circularProgressDrawable.setStrokeWidth(5f);
        circularProgressDrawable.setCenterRadius(30f);
        circularProgressDrawable.start();

        try {

            SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
            String finished_at =  list.get(position).getString("schedule_at");
            String status =  list.get(position).getString("status");
            holder.binding.status.setText(status);
            holder.binding.txtLocation.setText(list.get(position).optString("s_address"));
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = format.parse(finished_at);
            String dayOfTheWeek = (String) DateFormat.format("EEE", date); // Thursday
            String day          = (String) DateFormat.format("dd",   date); // 20
            String time          = (String) DateFormat.format("hh:mm a",   date);
            if (!TextUtils.isEmpty(finished_at))
            holder.binding.serviceTypeDate.setText(dayOfTheWeek + " " + day);
            if (!TextUtils.isEmpty(time))
            holder.binding.txtTime.setText(time);


            JSONObject objectProvider =  list.get(position).getJSONObject("user");
            String URL = SessionManager.STORAGE +objectProvider.getString("picture");
            holder.binding.providerName.setText(objectProvider.getString("first_name"));
            holder.binding.contact.setText(objectProvider.getString("mobile"));


            holder.binding.startService.setOnClickListener(v -> {
                new MaterialAlertDialogBuilder(context)
                        .setTitle(context.getString(R.string.app_name))
                        .setCancelable(false)
                        .setMessage("Are u sure want to proceed?")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                                startService(list.get(position).optString("id"));
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        })
                        .show();
            });

            holder.binding.cancel.setOnClickListener(v -> {
                new MaterialAlertDialogBuilder(context)
                        .setTitle(context.getString(R.string.app_name))
                        .setCancelable(false)
                        .setMessage("Are u sure want to cancel?")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                                cancelService(list.get(position).optString("id"));
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        })
                        .show();
            });
        } catch (JSONException | ParseException e) {
            e.printStackTrace();
        }
    }

    private void cancelService(String id) {
        StringRequest request = new StringRequest(Request.Method.POST, SessionManager.CANCEL_SERVICE, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.getJSONObject("response").has("status")) {
                        context.startActivity(new Intent(context, MainScreen.class));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> jsonObject = new HashMap<>();
                jsonObject.put("id", id);
                return jsonObject;
            }
        };
        MySingleton.getInstance(context).addToRequestQueue(request);
    }

    private void startService(String id) {
        StringRequest request = new StringRequest(Request.Method.POST, SessionManager.START_SERVICE, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.getJSONObject("response").has("status")) {
                        context.startActivity(new Intent(context, MainScreen.class));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> jsonObject = new HashMap<>();
                jsonObject.put("id", id);
                return jsonObject;
            }
        };
        MySingleton.getInstance(context).addToRequestQueue(request);
    }


    @Override
    public int getItemCount() {
        return list.size();
    }
    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }
}
