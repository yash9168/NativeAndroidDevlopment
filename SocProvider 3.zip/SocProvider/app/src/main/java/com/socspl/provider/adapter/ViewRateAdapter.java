package com.socspl.provider.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.CircularProgressDrawable;

import com.socspl.provider.R;
import com.socspl.provider.databinding.ItemViewRateBinding;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ViewRateAdapter extends RecyclerView.Adapter<ViewRateAdapter.ViewRateHolder> {

    class ViewRateHolder extends RecyclerView.ViewHolder{
        ItemViewRateBinding binding;
        public ViewRateHolder(@NonNull ItemViewRateBinding itemView) {
            super(itemView.getRoot());
            binding = itemView;
        }
    }

    Context context ;
    ArrayList<JSONObject> objects;
    public ViewRateAdapter(Context context, ArrayList<JSONObject> objects){
        this.context = context ;
        this.objects = objects ;
    }
    @NonNull
    @Override
    public ViewRateAdapter.ViewRateHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemViewRateBinding binding =  DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_view_rate,parent,false);
        return new ViewRateAdapter.ViewRateHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewRateAdapter.ViewRateHolder holder, int position) {

        try {
            holder.binding.spare.setText(objects.get(position).getString("spare_name"));
            holder.binding.price.setText(objects.get(position).getString("price"));
            if (position % 2 == 0) {
                holder.binding.rootView.setBackgroundColor(ContextCompat.getColor(context, R.color.bg_gray));
            } else
                holder.binding.rootView.setBackgroundColor(ContextCompat.getColor(context, R.color.white));

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        if (objects != null && objects.size() > 0) {
            return objects.size();
        } else
            return 0;
    }
    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

}

