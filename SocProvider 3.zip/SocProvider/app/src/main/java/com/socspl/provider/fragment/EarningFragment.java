package com.socspl.provider.fragment;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.socspl.provider.R;
import com.socspl.provider.adapter.EarningFragmentAdapter;
import com.socspl.provider.adapter.UpcomingServiceAdapter;
import com.socspl.provider.databinding.FragmentEarnigBinding;
import com.socspl.provider.util.MySingleton;
import com.socspl.provider.util.SessionManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class EarningFragment extends Fragment {

    private ArrayList<JSONObject> list ;
    private SessionManager manager ;
    private EarningFragmentAdapter adapter;
    FragmentEarnigBinding binding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_earnig, container, false);
        manager = new SessionManager(getContext());
        list = new ArrayList<>();

        binding.recycleTrazection.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL,false));
        adapter = new EarningFragmentAdapter(getContext(),list,"Upcoming");
        binding.recycleTrazection.setAdapter(adapter);

        getEarningFragment();


        return binding.getRoot();
    }
    double total_val;
    private void getEarningFragment() {
//        binding.progressBar.setVisibility(View.VISIBLE);
        StringRequest request = new StringRequest(Request.Method.POST, SessionManager.EARNINGS + manager.getUserId(), new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object1 = new JSONObject(response);
                    if (object1.has("earnings")) {
                        JSONObject earnings = object1.getJSONObject("earnings");
                        if (earnings.has("fully")) {
                            JSONArray accepted_array = earnings.getJSONArray("fully");

                            for (int i = 0; i <accepted_array.length() ; i++) {
                                JSONObject  object = accepted_array.getJSONObject(i);
                                list.add(object);
                                if (list.get(i).has("payment") && !TextUtils.isEmpty(list.get(i).optString("payment")) && list.get(i).optJSONObject("payment") != null) {
                                    double total = 0;
                                    JSONObject paymentObject = list.get(i).optJSONObject("payment");
                                    if (paymentObject.has("provider_commision_additional")) {
                                         total = paymentObject.optInt("provider_commision_additional");
                                    }
                                    double d = paymentObject.optDouble("provider_commision");
                                    total_val += total + d;

                                }
                            }
                        }

                    }
                    adapter.notifyDataSetChanged();
                    binding.txtWallet.setText(getString(R.string.rupees) + new DecimalFormat("##.##").format(total_val));
                } catch (JSONException e) {
                    Log.d("PastError ",""+e.getStackTrace());
                    e.printStackTrace();
                }
//                binding.progressBar.setVisibility(View.GONE);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println(error.toString());
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> map = new HashMap<>();
                map.put("id",manager.getUserId());
                return map;
            }
        };
        MySingleton.getInstance(getContext()).addToRequestQueue(request);
    }
}
