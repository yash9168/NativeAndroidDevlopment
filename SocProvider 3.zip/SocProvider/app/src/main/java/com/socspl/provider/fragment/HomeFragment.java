package com.socspl.provider.fragment;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.CircularProgressDrawable;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.socspl.provider.R;
import com.socspl.provider.activity.MainScreen;
import com.socspl.provider.activity.ServiceDetailActivity;
import com.socspl.provider.adapter.CustomInfoWindowAdapter;
import com.socspl.provider.databinding.FragmentHomeBinding;
import com.socspl.provider.util.CustPrograssbar;
import com.socspl.provider.util.MySingleton;
import com.socspl.provider.util.SessionManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class HomeFragment extends Fragment implements OnMapReadyCallback {
    FragmentHomeBinding binding;
    String[] permissions = new String[]{"android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"};
    GoogleMap map;
    SessionManager manager ;
    LatLng latLng;
    private Location lastKnownLocation;
    private boolean locationPermissionGranted;
    private final LatLng defaultLocation = new LatLng(-33.8523341, 151.2106085);
    private static final int DEFAULT_ZOOM = 15;
    private FusedLocationProviderClient fusedLocationProviderClient;
    private static final int PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 1;
    CustPrograssbar custPrograssbar;

    private static final String TAG = "HOME_FRAGMENT";
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_home, container, false);
        manager = new SessionManager(getActivity());
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(getActivity());
        // [START maps_current_place_map_fragment]
        SupportMapFragment mapFragment = (SupportMapFragment) this.getChildFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        custPrograssbar = new CustPrograssbar();
        binding.goOnline.setOnClickListener(v -> {
            if (binding.goOnline.getText().toString().equalsIgnoreCase("Go Online"))
                activateStatus("active");
            else
                activateStatus("offline");

        });

        getAvailabilityStatus();

        return binding.getRoot();
    }

    @Override
    public void onStart() {
        super.onStart();
//        checkIncomingServices();
    }

    private void checkIncomingServices() {
        StringRequest request = new StringRequest(Request.Method.GET, SessionManager.INCOMING + manager.getUserId(), new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object1 = new JSONObject(response);
                    JSONArray array = object1.getJSONArray("requests");
                    if (array.length() > 0) {
                        Intent intent = new Intent(getActivity(), ServiceDetailActivity.class);
                        intent.putExtra("data", response);
                        startActivity(intent);
                    }
                } catch (JSONException e) {
                    Log.d("PastError ",""+e.getStackTrace());
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> map = new HashMap<>();
                map.put("provider_id",manager.getUserId());
                return map;
            }
        };
        MySingleton.getInstance(getActivity()).addToRequestQueue(request);
    }



    private void activateStatus(String status) {
        custPrograssbar.prograssCreate(getActivity());
        StringRequest request = new StringRequest(Request.Method.POST, SessionManager.STATUS, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    getAvailabilityStatus();

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                    custPrograssbar.closePrograssBar();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                custPrograssbar.closePrograssBar();
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> param = new HashMap<>();
                param.put("id",manager.getUserId());
                param.put("service_status", status);
                return param;
            }
        };
        MySingleton.getInstance(getContext()).addToRequestQueue(request);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        map = googleMap;

        // Add a marker in Sydney and move the camera

        // Enable the zoom controls for the map
        map.getUiSettings().setZoomControlsEnabled(true);
        map.setOnMarkerDragListener(new GoogleMap.OnMarkerDragListener() {
            @Override
            public void onMarkerDragStart(Marker marker) {
            }

            @Override
            public void onMarkerDrag(Marker marker) {
            }

            @Override
            public void onMarkerDragEnd(Marker marker) {
                LatLng latLng = marker.getPosition();
                Geocoder geocoder = new Geocoder(getActivity(), Locale.getDefault());
                try {
                    android.location.Address address = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1).get(0);

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        getLocationPermission();
        getDeviceLocation();
        checkPermissions();
    }

    private void getLocationPermission() {
        /*
         * Request location permission, so that we can get the location of the
         * device. The result of the permission request is handled by a callback,
         * onRequestPermissionsResult.
         */
        if (ContextCompat.checkSelfPermission(getActivity(),
                android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            locationPermissionGranted = true;
        } else {
            ActivityCompat.requestPermissions(getActivity(),
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);
        }
    }

    private boolean checkPermissions() {
        ArrayList arrayList = new ArrayList();
        for (String str : this.permissions) {
            if (ContextCompat.checkSelfPermission(getActivity(), str) != 0) {
                arrayList.add(str);
            }
        }
        if (arrayList.isEmpty()) {
            return true;
        }
        ActivityCompat.requestPermissions(getActivity(), (String[]) arrayList.toArray(new String[arrayList.size()]), 100);
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        locationPermissionGranted = false;
        switch (requestCode) {
            case PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    locationPermissionGranted = true;
                }
            }
        }
        updateLocationUI();
    }
    private void updateLocationUI() {
        if (map == null) {
            return;
        }
        try {
            if (locationPermissionGranted) {
                map.setMyLocationEnabled(true);
                map.getUiSettings().setMyLocationButtonEnabled(true);
            } else {
                map.setMyLocationEnabled(false);
                map.getUiSettings().setMyLocationButtonEnabled(false);
                lastKnownLocation = null;
                getLocationPermission();
            }
        } catch (SecurityException e)  {
            Log.e("Exception: %s", e.getMessage());
        }
    }

    private void getDeviceLocation() {

        try {
            Task<Location> locationResult = fusedLocationProviderClient.getLastLocation();
            locationResult.addOnCompleteListener(getActivity(), new OnCompleteListener<Location>() {
                @Override
                public void onComplete(@NonNull Task<Location> task) {
                    if (task.isSuccessful()) {
                        // Set the map's camera position to the current location of the device.
                        lastKnownLocation = task.getResult();
                        if (lastKnownLocation != null) {
                            map.moveCamera(CameraUpdateFactory.newLatLngZoom(
                                    new LatLng(lastKnownLocation.getLatitude(),
                                            lastKnownLocation.getLongitude()), DEFAULT_ZOOM));
                            latLng = new LatLng(lastKnownLocation.getLatitude(),lastKnownLocation.getLongitude());
                            int height = 120;
                            int width = 120;
                            Bitmap b = BitmapFactory.decodeResource(getResources(), R.drawable.location);
                            Bitmap smallMarker = Bitmap.createScaledBitmap(b, width, height, false);
                            BitmapDescriptor smallMarkerIcon = BitmapDescriptorFactory.fromBitmap(smallMarker);
                            CustomInfoWindowAdapter adapter = new CustomInfoWindowAdapter(getActivity());
                            map.setInfoWindowAdapter(adapter);
                            map.addMarker(new MarkerOptions().position(latLng).draggable(true).title(getString(R.string.you_are_here)).icon(smallMarkerIcon)).showInfoWindow();
                            map.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                            Geocoder geocoder = new Geocoder(getActivity(), Locale.getDefault());
                            try {
                                android.location.Address address = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1).get(0);

                            } catch (IOException e) {
                                e.printStackTrace();
                            }

                        }
                    } else {
                        Log.d(TAG, "Current location is null. Using defaults.");
                        Log.e(TAG, "Exception: %s", task.getException());
                        map.moveCamera(CameraUpdateFactory
                                .newLatLngZoom(defaultLocation, DEFAULT_ZOOM));
                        map.getUiSettings().setMyLocationButtonEnabled(true);
                    }
                }
            });

        } catch (SecurityException e)  {
            Log.e("Exception: %s", e.getMessage(), e);
        }
    }

    private void getAvailabilityStatus() {
        custPrograssbar.prograssCreate(getActivity());
        StringRequest request = new StringRequest(Request.Method.POST, SessionManager.GET_STATUS, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.has("status") && object.has("success")) {
                        if (object.optString("status").equalsIgnoreCase("active"))
                            binding.goOnline.setText("Go Offline");
                        else
                            binding.goOnline.setText("Go Online");
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                custPrograssbar.closePrograssBar();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                custPrograssbar.closePrograssBar();
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> param = new HashMap<>();
                param.put("provider_id",manager.getUserId());
                return param;
            }
        };
        MySingleton.getInstance(getContext()).addToRequestQueue(request);
    }
}
