package com.socspl.provider.fragment;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.CircularProgressDrawable;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.canhub.cropper.CropImage;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.socspl.provider.R;
import com.socspl.provider.activity.EditProfile;
import com.socspl.provider.activity.LoginActivity;
import com.socspl.provider.activity.ServiceDetailActivity;
import com.socspl.provider.databinding.EditProfileFragmentBinding;
import com.socspl.provider.util.CustPrograssbar;
import com.socspl.provider.util.MySingleton;
import com.socspl.provider.util.SessionManager;
import com.socspl.provider.util.ToastMessage;
import com.squareup.picasso.Picasso;

import net.gotev.uploadservice.MultipartUploadRequest;
import net.gotev.uploadservice.ServerResponse;
import net.gotev.uploadservice.UploadInfo;
import net.gotev.uploadservice.UploadStatusDelegate;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

public class ProfileFragment extends Fragment {
    EditProfileFragmentBinding binding;
    SessionManager manager;
    CustPrograssbar custPrograssbar;
    private Uri uriPath;
    String filePath;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = DataBindingUtil.inflate(inflater, R.layout.edit_profile_fragment, container, false);
        manager = new SessionManager(getActivity());
        custPrograssbar = new CustPrograssbar();
        getProfile();

        binding.topAppBar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()){
                    case R.id.logout:
                        new MaterialAlertDialogBuilder(getActivity())
                                .setTitle(getString(R.string.app_name))
                                .setCancelable(false)
                                .setMessage("Are u sure want to logout")
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.dismiss();
                                        logout();
                                    }
                                })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                })
                                .show();
                        break;
                }

                return true;
            }
        });

        binding.imageViewEditPro.setOnClickListener(v -> {
            CropImage.activity()
                    .start( getActivity());
        });

        binding.buttonEditProfile.setOnClickListener(v -> {
            updateProfile();

        });

        binding.editProfile.setOnClickListener(v -> {
            startActivity(new Intent(getActivity(), EditProfile.class));
        });
        return binding.getRoot();
    }

    @Override
    public void onStart() {
        super.onStart();
        if (!TextUtils.isEmpty(manager.getUserId()))
            getProfile();
    }

    private void getProfile() {
        custPrograssbar.prograssCreate(getActivity());
        StringRequest request = new StringRequest(Request.Method.POST, SessionManager.GET_PROFILE, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.has("status") && object.optBoolean("status")) {
                        JSONObject userObject = object.getJSONObject("user");
                        binding.editTextFirstNameEditProfile.setText(SessionManager.  checkNullString(userObject.optString("first_name")));
                        binding.editTextLastNameEditProfile.setText(SessionManager.checkNullString(userObject.optString("last_name")));
                        binding.editTextEmailEditProfile.setText(SessionManager.checkNullString(userObject.optString("email")));
                        binding.editTextDescriptionEditProfile.setText(SessionManager.checkNullString(userObject.optString("description")));
                        if (userObject.has("profile") &&  !userObject.isNull("profile"))
                        binding.editTextAddressEditProfile.setText(SessionManager.checkNullString(userObject.optJSONObject("profile").optString("address")));
                        binding.editTextPhoneEditProfile.setText(SessionManager.checkNullString(userObject.optString("mobile")));
                        CircularProgressDrawable circularProgressDrawable = new CircularProgressDrawable(getContext());
                        circularProgressDrawable.setStrokeWidth(5f);
                        circularProgressDrawable.setCenterRadius(30f);
                        circularProgressDrawable.start();
                        String URL = SessionManager.STORAGE + SessionManager.checkNullString(userObject.optString("avatar"));
                        Picasso.with(getContext()).load(URL).placeholder(circularProgressDrawable).error(R.drawable.ic_user_placeholder).into(binding.imageViewUserEditPro);

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                custPrograssbar.closePrograssBar();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                custPrograssbar.closePrograssBar();
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> param = new HashMap<>();
                param.put("provider_id",manager.getUserId());
                return param;
            }
        };
        MySingleton.getInstance(getContext()).addToRequestQueue(request);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {

            if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
                CropImage.ActivityResult result = CropImage.getActivityResult(data);
                if (resultCode == Activity.RESULT_OK) {
                    uriPath = result.getUriContent();
                    String s = "" + result.getUriContent();
                    CircularProgressDrawable circularProgressDrawable = new CircularProgressDrawable(getActivity());
                    circularProgressDrawable.setStrokeWidth(5f);
                    circularProgressDrawable.setCenterRadius(30f);
                    circularProgressDrawable.start();
                    Picasso.with(getActivity()).load(uriPath).placeholder(circularProgressDrawable).into(binding.imageViewUserEditPro);
                    filePath = result.getUriFilePath(getActivity(), true);
                } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                    Exception error = result.getError();
                }
            }
        }
    }

    private void updateProfile() {
        custPrograssbar.prograssCreate(getActivity());
        try {
            String uploadId = UUID.randomUUID().toString();
            //Creating a multi part request
            new MultipartUploadRequest(getActivity(), uploadId, SessionManager.UPDATE_PROFILE)
                    .addFileToUpload("picture", filePath) //Adding file
                    .addParameter("provider_id", manager.getUserId()) //Adding file
                    .addParameter("first_name", binding.editTextFirstNameEditProfile.getText().toString())
                    .addParameter("last_name", binding.editTextLastNameEditProfile.getText().toString())
                    .addParameter("address", binding.editTextAddressEditProfile.getText().toString())
                    .addParameter("description", binding.editTextDescriptionEditProfile.getText().toString())//Adding file
                    .setDelegate(new UploadStatusDelegate() {
                        @Override
                        public void onProgress(Context context, UploadInfo uploadInfo) {
                        }

                        @Override
                        public void onError(Context context, UploadInfo uploadInfo, ServerResponse serverResponse, Exception exception) {
                            new ToastMessage(getActivity()).showSmallCustomToast("Data Error" + exception);
                            custPrograssbar.closePrograssBar();
                        }

                        @Override
                        public void onCompleted(Context context, UploadInfo uploadInfo, ServerResponse serverResponse) {
                            // new ToastMessage(EditProfile.this).showSmallCustomToast(""+serverResponse.getBodyAsString());
                            custPrograssbar.closePrograssBar();

                            try {
                                JSONObject object = new JSONObject(serverResponse.getBodyAsString());
                                if (object.has("success") && object.optBoolean("success")) {
                                    new ToastMessage(getActivity()).showSmallCustomToast("Profile update successfully");
                                } else if (object.has("error")) {
                                    new ToastMessage(getActivity()).showSmallCustomToast(object.optString("error"));
                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }

                        @Override
                        public void onCancelled(Context context, UploadInfo uploadInfo) {
                            custPrograssbar.closePrograssBar();
                            new ToastMessage(getActivity()).showSmallCustomToast("Something went wrong");

                        }

                    })
                    .setMaxRetries(1)
                    .startUpload(); //Starting the upload


        } catch (Exception exc) {
            new ToastMessage(getActivity()).showSmallCustomToast(exc.getMessage());
        }
    }

    private void logout(){
        StringRequest request = new StringRequest(Request.Method.POST, SessionManager.LOGOUT, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.has("success")){
                        new SessionManager(getActivity()).clearData();
                        getActivity().finish();
                        startActivity(new Intent(getContext(), LoginActivity.class));
                    } else {
                        new ToastMessage(getActivity()).showSmallCustomToast("Something wrong.");
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                new ToastMessage(getActivity()).showSmallCustomToast(error.toString());
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> param = new HashMap<>();
                param.put("id",manager.getUserId());
                return param;
            }
        };
        MySingleton.getInstance(getActivity()).addToRequestQueue(request);

    }

}
