package com.socspl.provider.interfaces;

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
}

