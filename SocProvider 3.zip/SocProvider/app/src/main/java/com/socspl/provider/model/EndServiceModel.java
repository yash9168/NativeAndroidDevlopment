package com.socspl.provider.model;

import java.util.List;

public class EndServiceModel {
    protected String request_id;

    protected String status;

    protected String after_comment;

    protected String payment_mode;

    public String getRequest_id() {
        return request_id;
    }

    public void setRequest_id(String request_id) {
        this.request_id = request_id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAfter_comment() {
        return after_comment;
    }

    public void setAfter_comment(String after_comment) {
        this.after_comment = after_comment;
    }

    public String getPayment_mode() {
        return payment_mode;
    }

    public void setPayment_mode(String payment_mode) {
        this.payment_mode = payment_mode;
    }

    public List<InvoiceType> getInvoice_type() {
        return invoice_type;
    }

    public void setInvoice_type(List<InvoiceType> invoice_type) {
        this.invoice_type = invoice_type;
    }

    protected List<InvoiceType> invoice_type;
}
