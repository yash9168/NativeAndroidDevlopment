package com.socspl.provider.util;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.socspl.provider.R;


public class SessionManager {

    public static String BASE_URL = "https://www.socspl.com/api/provider/";
    public static String BASE_IMAGE_URL = "https://www.socspl.com/";
    public static String LOGIN  = BASE_URL + "signin";
    public static String ACCEPT_REQUEST  = BASE_URL + "accept_service";
    public static String REJECT_REQUEST  = BASE_URL + "reject_service";
    public static String STATUS  = BASE_URL + "available";
    public static String START_SERVICE  = BASE_URL + "start";
    public static String CANCEL_SERVICE  = BASE_URL + "cancel_service";
    public static String UPCOMING_SERVICE  = BASE_URL + "upcoming_services?provider_id=";
    public static String INCOMING  = BASE_URL + "incoming?provider_id=";
    public static String CHECK_OTP  = BASE_URL + "check_otp";
    public static String LOGOUT  = BASE_URL + "provider_logout";
    public static String STORAGE  = BASE_IMAGE_URL + "storage/";
    public static String STATUS_UPDATE  = BASE_URL + "update_service";
    public static String STATUS_INVOICE  = BASE_URL + "update_invoice";
    public static String RATE_USER  = BASE_URL + "rate";
    public static String GET_PROFILE  = BASE_URL + "get_profile";
    public static String UPDATE_PROFILE  = BASE_URL + "update_profile";
    public static String GET_STATUS  = BASE_URL + "get_status";
    public static String UPDATE_PAY_MODE  = BASE_URL + "update_paymode";
    public static String EARNINGS  = BASE_URL + "earnings?id=";
    public static String COMPLETE_REQUEST  = BASE_URL + "target?id=";

    private static final String PREF_NAME = "SOC";
    public static String CITY  = "https://www.socspl.com/api/user/city";

    private static final String USER_ID = "user_id";
    private static final String USER_F_NAME = "first_name";
    private static final String USER_L_NAME = "last_name";
    private static final String USER_EMAIL = "user_email";

    private static final String USER_MOBILE_NO = "user_mobile_no";
    private static final String USER_IMAGE = "user_image";
    private static final String USER_STATUS = "user_status";
    private static final String USER_Location = "user_location";
    private static final String RunningService = "running_service";


    private static String TAG = SessionManager.class.getSimpleName();

    // Shared Preferences
    SharedPreferences pref;

    SharedPreferences.Editor editor;
    Context _context;

    // Shared pref mode
    int PRIVATE_MODE = 0;

    public SessionManager(Context context) {
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    public static String checkNullString(String string){
        return  string.equals("null") ? "" : string ;
    }
    public static Object checkNullObject(Object string){
        return  string.equals(null) ? "" : string ;
    }
    public static int checkNullInt(int string){
        return  string == 0 ? 0 : string ;
    }

    public void setData(String user_id,String f_name,String l_name,String email,
                        String mobile,String image,String status,String location) {

        editor.putString(USER_ID, user_id);
        editor.putString(USER_F_NAME, f_name);
        editor.putString(USER_L_NAME, l_name);
        editor.putString(USER_EMAIL, email);
        editor.putString(USER_MOBILE_NO, mobile);
        editor.putString(USER_IMAGE,image );
        editor.putString(USER_STATUS,status );
        editor.putString(USER_Location,location );
        // commit changes
        editor.commit();

    }


    public void setData(String user_id) {

        editor.putString(USER_ID, user_id);
        // commit changes
        editor.commit();
        Log.d(TAG, "User login session modified!");
    }

    public void clearData() {
        editor.clear();
        editor.apply();
    }

    public String getPrefName() {
        return PREF_NAME;
    }


    public void setUserId(String user_id) {
        editor.putString(USER_ID, user_id);
        editor.commit();
        editor.apply();
    }

    public String getUserId() {
        return pref.getString(USER_ID, _context.getString(R.string.app_name));
    }

    public String getUserStatus() {
        return pref.getString(USER_ID, "0");
    }

    public void setUserFName(String user_name) {
        editor.putString(USER_F_NAME, user_name);
        editor.commit();
        editor.apply();
    }

    public String getUserFName() {
        return pref.getString(USER_F_NAME, _context.getString(R.string.app_name));
    }

    public void setUserLName(String user_name) {
        editor.putString(USER_L_NAME, user_name);
        editor.commit();
        editor.apply();
    }

    public String getUserLName() {
        return pref.getString(USER_L_NAME, _context.getString(R.string.app_name));
    }

    public void setUserEmail(String user_email) {
        editor.putString(USER_EMAIL, user_email);
        editor.commit();
        editor.apply();
    }

    public String getUserEmail() {
        return pref.getString(USER_EMAIL, _context.getString(R.string.app_name));
    }


    public String getUserMobileNo() {
        return pref.getString(USER_MOBILE_NO, _context.getString(R.string.app_name));
    }


    public String getUserImage() {
        return pref.getString(USER_IMAGE, _context.getString(R.string.app_name));
    }

    public String getUSER_Location() {
        return pref.getString(USER_Location, _context.getString(R.string.default_city_name));
    }

    public void setUSER_Location(String user_location) {
        editor.putString(USER_Location, user_location);
        editor.commit();
        editor.apply();
    }
    public void setUserImage(String image) {

        editor.putString(USER_IMAGE, image);
        editor.commit();
        editor.apply();
    }

    public void setRunningService(String isRunning) {
        editor.putString(RunningService, isRunning);
        editor.commit();
        editor.apply();
    }

    public String getRunningService() {
        return pref.getString(RunningService, _context.getString(R.string.app_name));
    }

    public static void showToast(Activity activity, String message) {
        new ToastMessage(activity).showSmallCustomToast(message);
    }
}
