package com.tutorial.weatherapp.view.activity.addloaction.presenter;


public interface AddLocationActivityPresenterHandler {

   void getData(String apiKey, String latitude, String longitude, String text);

}
