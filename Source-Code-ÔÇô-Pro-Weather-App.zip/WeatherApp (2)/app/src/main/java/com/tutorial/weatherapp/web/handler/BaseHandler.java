package com.tutorial.weatherapp.web.handler;

public interface BaseHandler {
    public void onError(String message);
}
