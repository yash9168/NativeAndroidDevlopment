package com.tutorial.weatherapp.web.handler;

public interface NearByPlacesHandler extends BaseHandler {

    void onSuccess(String response);
}
