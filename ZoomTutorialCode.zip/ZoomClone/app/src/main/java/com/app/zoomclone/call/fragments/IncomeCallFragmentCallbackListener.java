package com.app.zoomclone.call.fragments;


public interface IncomeCallFragmentCallbackListener {

    void onAcceptCurrentSession();

    void onRejectCurrentSession();
}