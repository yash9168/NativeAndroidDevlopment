package com.app.zoomclone.call.fragments;


public interface OnCallEventsController {

    void onUseHeadSet(boolean use);
}