package com.app.zoomclone.chat.qb;

public interface PaginationHistoryListener {
    void downloadMore();
}