package com.app.ola.call.fragments;


public interface IncomeCallFragmentCallbackListener {

    void onAcceptCurrentSession();

    void onRejectCurrentSession();
}