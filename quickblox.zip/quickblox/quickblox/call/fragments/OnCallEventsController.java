package com.app.ola.call.fragments;


public interface OnCallEventsController {

    void onUseHeadSet(boolean use);
}