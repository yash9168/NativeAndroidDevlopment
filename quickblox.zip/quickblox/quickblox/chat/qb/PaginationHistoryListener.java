package com.app.ola.chat.qb;

public interface PaginationHistoryListener {
    void downloadMore();
}